module.exports = {
  apps: [
    {
      name: "r2home-backend",
      script: "node ./dist/src/index.js",
      env: {
        VERSION: "1.0.0",

        HOST: "localhost",
        PORT: "4000",

        FRONTEND_APP_BASE_URL: "https://test.rush2homes.com",
        BACKEND_BASE_URL: "https://api.test.rush2homes.com",

        DB_HOST: "r2h-test-db.ccg0gvg6olpk.ap-south-1.rds.amazonaws.com",
        DB_USERNAME: "r2hadmin",
        DB_PASSWORD: "HM4haphJbQHx6qR",
        DATABASE: "rush_to_home",

        MAILER_NAME: "Rush 2 Homes",
        MAILER_EMAIL_ADDRESS: "support@rushlankagroup.com",
        MAILER_EMAIL_PASSWORD: "support@1123V",

        ACCESS_TOKEN_SECRET:
          "e887f64b50bc24150033bce5b73056c3b10fa68220013d35072b3261178141736a33c7714fddf5416fd5333ae23e78ff5094be2a78aec7d4d3c859d47cab4c84",
        REFRESH_TOKEN_SECRET: "secret",

        ACCESS_TOKEN_EXPIRE_TIME: "1h",
        REFRESH_TOKEN_EXPIRE_TIME: "30d",

        GOOGLE_CLIENT_ID:
          "367566552712-43q9mknmlcvolsvk6mhmabqer9phsavr.apps.googleusercontent.com",
        GOOGLE_CLIENT_SECRET: "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",

        FACEBOOK_APP_ID: "982336289390352",
        FACEBOOK_APP_SECRET: "e81be3e6eb5da913724b5423f9d66d91",

        SHOUTOUT_OTP_API_BASE_URL: "https://api.getshoutout.com/otpservice",
        SHOUTOUT_OTP_API_KEY:
          "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJjNmQ2NmMxMC0xZDI1LTExZWQtOGU5Ni00YjhlMzMyY2M5OTUiLCJzdWIiOiJTSE9VVE9VVF9BUElfVVNFUiIsImlhdCI6MTY2MDYyODM2MCwiZXhwIjoxOTc2MjQ3NTYwLCJzY29wZXMiOnsiYWN0aXZpdGllcyI6WyJyZWFkIiwid3JpdGUiXSwibWVzc2FnZXMiOlsicmVhZCIsIndyaXRlIl0sImNvbnRhY3RzIjpbInJlYWQiLCJ3cml0ZSJdfSwic29fdXNlcl9pZCI6IjczMjQ2Iiwic29fdXNlcl9yb2xlIjoidXNlciIsInNvX3Byb2ZpbGUiOiJhbGwiLCJzb191c2VyX25hbWUiOiIiLCJzb19hcGlrZXkiOiJub25lIn0.22mx_VNAufRIYXRmHEWeTIBNyFo7F99WGtO3Wv0-Dao",
      },
    },
  ],
};
