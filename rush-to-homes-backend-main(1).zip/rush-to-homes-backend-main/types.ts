import { AdvertisementEntity } from "./src/entities";

export type MetadataType = {
  key: string;
  value: string | number | boolean;
};

export type PropertyDetailsInnerHtmlType = {
  __html: string;
};

export type PropertyDataType = {
  id: number;
  title: string;
  price: number;
  propertyMainDetails: MetadataType[];
  propertyFeatures: string[];
  propertyDetails: PropertyDetailsInnerHtmlType;
  images: { fileName: string; url: string }[];
  isSave: boolean;
  user?: {
    userId: number;
    firstName: string;
    lastName: string;
    countryCode: string;
    phoneNumber: string;
  };
};

export interface FilterParams {
  searchStr: string[];
  propertyTypes: string[];
  // priceRangeType: string;
  priceRangeMin: number | undefined;
  priceRangeMax: number | undefined;
  district: string | undefined;
  city: string | undefined;
  landRangeType: string;
  landRangeMin: number | undefined;
  landRangeMax: number | undefined;
  sortBy?: string;
  sortOrder: "ASC" | "DESC";
  searchType: string;
}

export interface ReportedAddDataType {
  advertisementId: number;
  name: string;
  email: string;
  contactNumber: string;
  reason: string;
  details: string;
}

export interface SavedAddDataType {
  userId: number;
}

export interface User {
  id?: number;
  firstName?: string;
  lastName?: string;
  userName?: string;
  password?: string;
  email?: string;
  countryCode?: string;
  phoneNumber?: string;
  isAdmin?: boolean;
}

export interface Admin {
  id?: number;
  firstName?: string;
  lastName?: string;
  userName?: string;
  password?: string;
  email?: string;
  countryCode?: string;
  phoneNumber?: string;
  isAdmin?: boolean;
}

export type NewMessage = {
  senderId: number;
  receiverId: number;
  advertisementId: number;
  text: string;
};

export type CategoryData = {
  id?: number;
  nameEn: string;
  nameSi: string;
  nameTa: string;
  metaTitle?: string;
  metaDescription?: string;
  adGroup?: string;
  additionalDetails?: string;
  propertyFeatures?: string;
  updatedDate?: string;
}

export type AdRemarkData = {
  id?: number;
  remark: string;
  status: number;
  createdDate?: Date;
  advertisement: AdvertisementEntity;
}
