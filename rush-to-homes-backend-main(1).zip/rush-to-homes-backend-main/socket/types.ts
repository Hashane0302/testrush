export interface Message {
  senderId: number;
  receiverId: string;
  text: string;
  advertisementId: string;
}
