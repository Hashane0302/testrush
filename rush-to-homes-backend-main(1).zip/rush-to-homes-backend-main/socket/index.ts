import { Socket, Server } from "socket.io";
import { Message } from "./types";

const addUser = async (io: Server, socket: Socket, data: { userId: string }) => {
  try {
    const userId = data.userId;
    if (!userId) return;
    
    socket.join(`USER_ROOM_${userId}`);

    console.log([`User joined USER_ROOM_${userId}`]);

    io.to(`USER_ROOM_${userId}`).emit("messageList", { refresh: true });

  } catch (_) {
    console.log(_);
  }
};

const sendMessage = async (io: Server, data: Message) => {  
  try {
    const { senderId, receiverId } = data;

    console.log([`USER_ROOM_${receiverId}`, `USER_ROOM_${senderId}`]);

    io.to([`USER_ROOM_${receiverId}`, `USER_ROOM_${senderId}`]).emit("getMessage", { refresh: true });

    // io.to(`USER_ROOM_${receiverId}`).emit("messageList", { refresh: true });
  } catch (_) {
    console.log(_);
  }
};

// const updateReadMessage = async (io: Server, socket: Socket, data: { userId: number, adId: string, otherUserId: string }) => {
//   try {
//     const { adId, otherUserId, userId } = data;
//     if (!userId || !adId || !otherUserId) return;

//     io.to(`USER_ROOM_${userId}`).emit("messageList", { refresh: true });
//   } catch (_) {
//     console.log(_);
//   }
// };

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const processCommand = (io: Server, socket: Socket, command: string, data: any) => {
  console.log("c:", command, "data:", data);
  switch (command) {
    case "addUser":
      addUser(io, socket, data);
      break;

    case "sendMessage":
      sendMessage(io, data);
      break;

    // case "updateReadMessage":
    //   updateReadMessage(io, socket, data);
    //   break;
  }
};


