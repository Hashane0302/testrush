import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm";
import { AdvertisementEntity } from "./advertisement.entity";

@Entity({ name: "image" })
export class ImageEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "advertisement_id", type: "integer" })
  advertisementId: number;

  @Column({ name: "file_name", type: "varchar", length: 300 })
  fileName: string;

  @Column({ name: "location_url", type: "varchar", length: 255 })
  locationUrl: string;

  @Column({
    name: "created_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  createdDate: Date;

  @ManyToOne(() => AdvertisementEntity, (advertisement) => advertisement.images, { onDelete: "CASCADE" })
  @JoinColumn([{ name: "advertisement_id", referencedColumnName: "id" }])
  advertisement: AdvertisementEntity;
}
