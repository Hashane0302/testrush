import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
  ManyToMany,
} from "typeorm";
import { UserEntity } from "./user.entity";
import { ImageEntity } from "./image.entity";
import { ReportAdEntity } from "./report-ad.entity";
import { PropertyFeatureEntity } from "./property-feature.entity";
import { AdRemarksEntity } from "./ad-remarks.entity";
import { ConversationEntity } from "./conversation.entity";

@Entity({ name: "advertisement" })
export class AdvertisementEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "user_id", type: "integer" })
  userId: number;

  @Column({ name: "offer_type", type: "varchar", length: 255 })
  offerType: string;

  @Column({ name: "property_type", type: "varchar", length: 255 })
  propertyType: string;

  @Column({ name: "price", type: "double", default: 0 })
  price: number;

  @Column({ name: "price_unit", type: "varchar", length: 20, default: null, nullable: true })
  priceUnit: string;

  @Column({ name: "title", type: "varchar", length: 255 })
  title: string;

  @Column({ name: "bedroom", type: "integer", nullable: true })
  bedroom: number;

  @Column({ name: "bathroom", type: "integer", nullable: true })
  bathroom: number;

  @Column({ name: "floor_area", type: "integer", nullable: true })
  floorArea: number;

  @Column({ name: "floor", type: "integer", nullable: true })
  floor: number;

  @Column({ name: "car_parking_space", type: "integer", nullable: true })
  carParkingSpace: number;

  @Column({ name: "land_area", type: "integer", nullable: true })
  landArea: number;

  @Column({ name: "property_details", type: "text", nullable: true })
  propertyDetails: string;

  @Column({ name: "district", type: "varchar", length: 255, nullable: true })
  district: string;

  @Column({ name: "city", type: "varchar", length: 255, nullable: true })
  city: string;

  @OneToMany(() => PropertyFeatureEntity, (propertyFeature) => propertyFeature.advertisement)
  @JoinColumn([{ name: "id", referencedColumnName: "advertisement_id" }])
  propertyFeatures: PropertyFeatureEntity[];

  @Column({ name: "search_string", type: "mediumtext", nullable: true })
  searchString: string;

  @Column({ name: "status", type: "tinyint", nullable: false, default: 0, comment: "0 - draft/proceed payment, 1 - in review,  2 - requested for amend, 3 - active, 4 - expired, 5 - rejected" })
  status: number;

  @Column({
    name: "created_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  createdDate: Date;

  @Column({
    name: "updated_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  updatedDate: Date;

  @ManyToOne(() => UserEntity, (user) => user.advertisements)
  @JoinColumn([{ name: "user_id", referencedColumnName: "id" }])
  user: UserEntity;

  @OneToMany(() => ImageEntity, (image) => image.advertisement)
  @JoinColumn([{ name: "id", referencedColumnName: "advertisement_id" }])
  images: ImageEntity[];

  @OneToMany(() => ReportAdEntity, (report) => report.advertisement)
  @JoinColumn([{ name: "id", referencedColumnName: "advertisement_id" }])
  reports: ReportAdEntity[];

  @ManyToMany(() => UserEntity, (user) => user.favoriteAds, { onDelete: "CASCADE" })
  favoriteUsers: UserEntity[];

  @OneToMany(() => AdRemarksEntity, (adRemark) => adRemark.advertisement)
  remarks: AdRemarksEntity[];

  @OneToMany(() => ConversationEntity, (conversation) => conversation.ad)
  conversations: ConversationEntity[];
}
