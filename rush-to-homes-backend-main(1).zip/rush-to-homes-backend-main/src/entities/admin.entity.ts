import {
    Entity,
    Column,
    PrimaryGeneratedColumn
  } from "typeorm";
  
  @Entity({ name: "admin" })
  export class AdminEntity {
    @PrimaryGeneratedColumn({ name: "id", type: "integer" })
    id: number;
  
    @Column({ name: "first_name", type: "varchar", length: 255 })
    firstName: string;
  
    @Column({ name: "last_name", type: "varchar", length: 255 })
    lastName: string;
  
    @Column({ name: "password", type: "varchar", length: 255, nullable: true })
    password: string;
  
    @Column({ name: "email", type: "varchar", length: 255 })
    email: string;
  
    @Column({ name: "country_code", type: "varchar", length: 10, nullable: true })
    countryCode: string;
  
    @Column({
      name: "phone_number",
      type: "varchar",
      length: 255,
      nullable: true,
    })
    phoneNumber: string;
  
    @Column({ name: "is_verified", type: "boolean", default: false })
    isVerified: boolean;
  
    @Column({ name: "otp_reference_id", type: "varchar", length: 50, nullable: true })
    otpReferenceId: string;
  
    @Column({ name: "is_phone_no_verified", type: "boolean", default: false })
    isPhoneNoVerified: boolean;
  
    @Column({
      name: "created_date",
      type: "timestamp",
      default: () => "CURRENT_TIMESTAMP",
    })
    createdDate: Date;
  
    @Column({ name: "is_admin", type: "boolean", default: true })
    isAdmin: boolean;
  }
  