import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from "typeorm";
import { ConversationEntity } from "./conversation.entity";
import { UserEntity } from "./user.entity";

@Entity({ name: "message" })
export class MessageEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "text", type: "varchar", length: 300 })
  text: string;

  @Column({ name: "read",  type: "tinyint", default: 0 })
  read: boolean;

  @Column({
    name: "created_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  createdDate: string;

  @Column({
    name: "updated_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  updatedDate: string;

  @ManyToOne(() => UserEntity, (user) => user.messages)
  user: UserEntity;

  @ManyToOne(() => ConversationEntity, (conversation) => conversation.messages)
  conversation: ConversationEntity;
}
