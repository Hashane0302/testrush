import {
  Entity,
  PrimaryColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm";
import { AdvertisementEntity } from "./advertisement.entity";

@Entity({ name: "property_feature" })
export class PropertyFeatureEntity {
  @PrimaryColumn({ name: "advertisement_id", type: "integer" })
  advertisementId: number;

  @PrimaryColumn({ name: "feature", type: "varchar", length: 255 })
  feature: string;

  @ManyToOne(() => AdvertisementEntity, (advertisement) => advertisement.propertyFeatures, { onDelete: "CASCADE" })
  @JoinColumn([{ name: "advertisement_id", referencedColumnName: "id" }])
  advertisement: AdvertisementEntity;
}