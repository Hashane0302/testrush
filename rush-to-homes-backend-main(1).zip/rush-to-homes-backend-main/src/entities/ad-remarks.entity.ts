import {
    Entity,
    Column,
    PrimaryGeneratedColumn,
    ManyToOne,
    JoinColumn,
  } from "typeorm";
  import { AdvertisementEntity } from "./advertisement.entity";
  
  @Entity({ name: "ad_remarks" })
  export class AdRemarksEntity {
    @PrimaryGeneratedColumn({ name: "id", type: "integer" })
    id: number;
  
    @Column({ name: "remark", type: "text", nullable: false })
    remark: string;
  
    @Column({ name: "status", type: "tinyint", nullable: false })
    status: number;
  
    @Column({
      name: "created_date",
      type: "timestamp",
      default: () => "CURRENT_TIMESTAMP",
    })
    createdDate: Date;
  
    @ManyToOne(() => AdvertisementEntity, (advertisement) => advertisement.remarks, { onDelete: "CASCADE" })
    @JoinColumn([{ name: "advertisement_id", referencedColumnName: "id" }])
    advertisement: AdvertisementEntity;
  }
  