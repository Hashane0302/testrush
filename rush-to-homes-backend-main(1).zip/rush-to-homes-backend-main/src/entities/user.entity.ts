import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  OneToMany,
  JoinColumn,
  ManyToMany,
  JoinTable,
} from "typeorm";
import { ConversationEntity } from "./conversation.entity";
import { AdvertisementEntity } from "./advertisement.entity";
import { MessageEntity } from "./message.entity";
import { AdditionalPhoneNumberEntity } from "./additional-phone-number.entity";

@Entity({ name: "user" })
export class UserEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "first_name", type: "varchar", length: 255 })
  firstName: string;

  @Column({ name: "last_name", type: "varchar", length: 255 })
  lastName: string;

  @Column({ name: "password", type: "varchar", length: 255, nullable: true, select: false })
  password: string;

  @Column({ name: "email", type: "varchar", length: 255 })
  email: string;

  @Column({ name: "country_code", type: "varchar", length: 10, nullable: true })
  countryCode: string;

  @Column({
    name: "phone_number",
    type: "varchar",
    length: 255,
    nullable: true,
    unique: true,
  })
  phoneNumber: string;

  @Column({ name: "is_verified", type: "boolean", default: false })
  isVerified: boolean;

  @Column({
    name: "otp_reference_id",
    type: "varchar",
    length: 50,
    nullable: true,
  })
  otpReferenceId: string;

  @Column({ name: "is_phone_no_verified", type: "boolean", default: false })
  isPhoneNoVerified: boolean;

  @Column({ name: "profile_img", type: "varchar", length: 255, default: "" })
  profileImg: string;

  @Column({
    name: "created_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  createdDate: Date;

  @Column({ name: "is_admin", type: "boolean", default: false })
  isAdmin: boolean;

  @OneToMany(() => AdvertisementEntity, (advertisement) => advertisement.user)
  @JoinColumn([{ name: "id", referencedColumnName: "user_id" }])
  advertisements: AdvertisementEntity[];

  @ManyToMany(
    () => AdvertisementEntity,
    (advertisement) => advertisement.favoriteUsers,
    { onDelete: "CASCADE" }
  )
  @JoinTable({
    name: "save_ad",
    joinColumn: {
      name: "user_id",
      referencedColumnName: "id",
      foreignKeyConstraintName: "fk_user_id",
    },
    inverseJoinColumn: {
      name: "advertisement_id",
      referencedColumnName: "id",
      foreignKeyConstraintName: "fk_advertisement_id",
    },
  })
  favoriteAds: AdvertisementEntity[];

  @ManyToMany(() => ConversationEntity, (conversation) => conversation.users)
  @JoinTable()
  conversations: ConversationEntity[];

  @OneToMany(() => MessageEntity, (message) => message.user)
  messages: MessageEntity[];

  @OneToMany(() => AdditionalPhoneNumberEntity, (additionalPhones) => additionalPhones.user)
  additionalPhones: AdditionalPhoneNumberEntity[];
}
