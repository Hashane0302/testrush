import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm";
import { AdvertisementEntity } from "./advertisement.entity";

@Entity({ name: "report_ad" })
export class ReportAdEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "advertisement_id", type: "integer" })
  advertisementId: number;

  @Column({ name: "name", type: "varchar", length: 255 })
  name: string;

  @Column({ name: "email", type: "varchar", length: 255 })
  email: string;

  @Column({ name: "contact_number", type: "varchar", length: 20 })
  contactNumber: string;

  @Column({ name: "reason", type: "varchar", length: 255 })
  reason: string;

  @Column({ name: "details", type: "varchar", length: 255 })
  details: string;

  @Column({
    name: "created_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  createdDate: Date;

  @ManyToOne(
    () => AdvertisementEntity,
    (advertisement) => advertisement.reports,
    { onDelete: "CASCADE" }
  )
  @JoinColumn([{ name: "advertisement_id", referencedColumnName: "id" }])
  advertisement: AdvertisementEntity;
}
