import { Column, Entity, ManyToOne, PrimaryColumn, PrimaryGeneratedColumn } from "typeorm";
import { UserEntity } from "./user.entity";

@Entity({ name: "additional_phone_number" })
export class AdditionalPhoneNumberEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @PrimaryColumn({ name: "phone_number", type: "varchar", length: 255 })
  phoneNumber: string;

  @Column({ name: "country_code", type: "varchar", length: 5 })
  countryCode: string;

  @Column({ name: "verified" })
  verified: boolean;

  @Column({ name: "otp_reference", type: "varchar", length: 255 })
  otpReference: string;

  @ManyToOne(() => UserEntity, (user) => user.additionalPhones)
  user: UserEntity;
}
