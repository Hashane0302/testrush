import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
} from "typeorm";

@Entity({ name: "category" })
export class CategoryEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "name_en", type: "varchar", length: 255, default: null })
  nameEn: string;

  @Column({ name: "name_si", type: "varchar", length: 255, default: null })
  nameSi: string;

  @Column({ name: "name_ta", type: "varchar", length: 255, default: null })
  nameTa: string;

  @Column({ name: "meta_title", type: "varchar", length: 255, default: "Rush 2 Homes - Go for it" })
  metaTitle: string;

  @Column({ name: "meta_description", type: "text", nullable: true })
  metaDescription: string;

  @Column({ name: "ad_group", type: "varchar", length: 255, default: "{\"Sale\":false,\"Rent\":false}" })
  adGroup: string;

  @Column({ name: "additional_details", type: "varchar", length: 120, default: "{\"bedroom\":false,\"bathroom\":false,\"floor_area\":false,\"floor\":false,\"car_parking_space\":false,\"land_area\":false}" })
  additionalDetails: string;

  @Column({ name: "property_features", type: "text", nullable: false })
  propertyFeatures: string;

  @Column({
    name: "created_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  createdDate: string;

  @Column({
    name: "updated_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  updatedDate: string;
}