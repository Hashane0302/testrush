import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity({ name: "banner" })
export class BannerEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "location_url", type: "varchar", length: 1000 })
  locationUrl: string;

  @Column({ name: "file_name", type: "varchar", length: 300 })
  fileName: string;

  @Column({ name: "is_active", type: "boolean", default: false })
  isActive: boolean;

  @Column({ name: "views", type: "integer", default: 0 })
  views: number;

  @Column({
    name: "created_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  createdDate: string;

  @Column({
    name: "updated_date",
    type: "timestamp",
    default: () => "CURRENT_TIMESTAMP",
  })
  updatedDate: string;
}
