import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm";
import { DistrictEntity } from "./district.entity";

@Entity({ name: "cities" })
export class CityEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "district_id", type: "integer", nullable: false })
  districtId: string;

  @Column({ name: "name_en", type: "varchar", length: 45, default: null })
  nameEn: string;

  @Column({ name: "name_si", type: "varchar", length: 45, default: null })
  nameSi: string;

  @Column({ name: "name_ta", type: "varchar", length: 45, default: null })
  nameTa: string;

  @Column({ name: "sub_name_en", type: "varchar", length: 45, default: null })
  subNameEn: string;

  @Column({ name: "sub_name_si", type: "varchar", length: 45, default: null })
  subNameSi: string;

  @Column({ name: "sub_name_ta", type: "varchar", length: 45, default: null })
  subNameTa: string;

  @Column({ name: "postcode", type: "varchar", length: 5, default: null })
  postCode: string;

  @Column({ name: "latitude", type: "decimal", default: null })
  latitude: string;

  @Column({ name: "longitude", type: "decimal", default: null })
  longitude: string;

  @ManyToOne(() => DistrictEntity, (district) => district.cities)
  @JoinColumn([{ name: "district_id", referencedColumnName: "id" }])
  district: DistrictEntity;
}
