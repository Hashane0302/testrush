import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  OneToMany,
  JoinColumn,
} from "typeorm";
import { DistrictEntity } from "./district.entity";

@Entity({ name: "provinces" })
export class ProvinceEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "name_en", type: "varchar", length: 45, default: null })
  nameEn: string;

  @Column({ name: "name_si", type: "varchar", length: 45, default: null  })
  nameSi: string;

  @Column({ name: "name_ta", type: "varchar", length: 45, default: null  })
  nameTa: string;

  @OneToMany(() => DistrictEntity, (district) => district.province)
  @JoinColumn([{ name: "id", referencedColumnName: "province_id" }])
  districts: DistrictEntity[];
}
