import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
} from "typeorm";
import { ProvinceEntity } from "./province.entity";
import { CityEntity } from "./city.entity";

@Entity({ name: "districts" })
export class DistrictEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @Column({ name: "province_id", type: "integer", nullable: false })
  provinceId: string;

  @Column({ name: "name_en", type: "varchar", length: 45, default: null })
  nameEn: string;

  @Column({ name: "name_si", type: "varchar", length: 45, default: null })
  nameSi: string;

  @Column({ name: "name_ta", type: "varchar", length: 45, default: null })
  nameTa: string;

  @ManyToOne(() => ProvinceEntity, (province) => province.districts)
  @JoinColumn([{ name: "province_id", referencedColumnName: "id" }])
  province: ProvinceEntity;

  @OneToMany(() => CityEntity, (city) => city.district)
  @JoinColumn([{ name: "id", referencedColumnName: "district_id" }])
  cities: CityEntity[];
}
