import { Entity, PrimaryGeneratedColumn, ManyToOne, OneToMany, ManyToMany } from "typeorm";
import { AdvertisementEntity, MessageEntity, UserEntity } from ".";

@Entity({ name: "conversation" })
export class ConversationEntity {
  @PrimaryGeneratedColumn({ name: "id", type: "integer" })
  id: number;

  @ManyToOne(() => AdvertisementEntity, (ad) => ad.conversations)
  ad: AdvertisementEntity;

  @ManyToMany(() => UserEntity, (user) => user.conversations)
  users: UserEntity[];

  @OneToMany(() => MessageEntity, (message) => message.conversation)
  messages: MessageEntity[];
}
