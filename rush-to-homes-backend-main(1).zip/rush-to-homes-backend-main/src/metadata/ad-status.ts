export const adStatus: {
  [key: string]: number;
} = {
  "draft": 0,
  "proceed payment": 0,
  "in review": 1,
  "requested for amend": 2,
  "active": 3,
  "expired": 4,
  "rejected": 5
};