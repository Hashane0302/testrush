export const accountActivationEmail = (url: string) => {
    return `<p>Welcome!</p>

    <p>Thank you for signing up with Rush 2 Homes.</p>
    
    <p>To complete your registration and place ads, we require you to confirm the authenticity of your e-mail address.</p>
    
    <p>To do so, click the following link: ${url}</p>
    
    <p>If you didn't sign up for this account, or you are having trouble with your account, feel free to contact us at support@rush2homes.com and we will be happy to help you.</p>
    
    <p>Best Regards,<br />
    Rush 2 Homes Support Team</p>`;
};

export const passwordResetEmail = (name: string, token: string) => {
    return `<p>Hi ${name},</p>
    
    <p>A request has been received to change the password for your Rush 2 Homes account.</p>
    
    <p>To reset your password, please click <a href="${process.env.FRONTEND_APP_BASE_URL}/?action=passwordReset&token=${token}" target="_blank">this link</a></p>
    
    <p>If you did not initiate this request, please contact us immediately at support@rush2homes.com.</p>
    
    <p>Best Regards,<br />
    Rush 2 Homes Support Team</p>`;
};