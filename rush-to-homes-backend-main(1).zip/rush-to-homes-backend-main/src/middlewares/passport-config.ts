import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Strategy as JwtStrategy } from "passport-jwt";
import {
  Strategy as GoogleStrategy,
  Profile,
  VerifyCallback,
} from "passport-google-oauth20";
import { Strategy as FacebookStrategy } from "passport-facebook";
import {
  getUserByUserId,
  getUserByEmail,
  insertNewUser,
} from "../repositories/user";
import bcrypt from "bcrypt";
import { Request } from "express";
import version from "../version";

passport.use(
  new LocalStrategy(
    { usernameField: "email", passwordField: "password" },
    (username, password, done) => {
      getUserByEmail(username)
        .then(async (user) => {
          if (!user) return done(null, false);
          if (!(await bcrypt.compare(password, user.password)))
            return done(null, false);
          return done(null, user);
        })
        .catch((err) => {
          return done(err);
        });
    }
  )
);

passport.use(
  new JwtStrategy(
    {
      jwtFromRequest: (req: Request) => {
        if (!req.headers.authorization) return "";
        else {
          return req.headers.authorization.replace("Bearer", "").trim();
        }
      },
      secretOrKey: `${process.env.ACCESS_TOKEN_SECRET}`,
    },
    (payload: { id: number }, done: any) => {
      getUserByUserId(payload.id)
        .then((user) => {
          if (user) return done(null, user);
          else return done(null, false);
        })
        .catch((err) => {
          return done(err);
        });
    }
  )
);

passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID || "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
      callbackURL: `/v${
        version?.split(".")[0]
      }/api/auth/google/callback`,
      passReqToCallback: true,
    },
    (
      request: Request,
      accessToken: string,
      refreshToken: string,
      profile: Profile,
      done: VerifyCallback
    ) => {
      const firstName = profile._json.given_name;
      const lastName = profile._json.family_name;
      const email = profile._json.email || "";

      getUserByEmail(email)
        .then((user) => {
          if (user) {
            return done(null, user);
          } else {
            insertNewUser({ firstName, lastName, email, isVerified: true })
              .then(() => {
                getUserByEmail(email)
                  .then((newUser) => {
                    if (newUser) return done(null, newUser);
                    else return done(null, false);
                  })
                  .catch((err) => done(err));
              })
              .catch((err) => done(err));
          }
        })
        .catch((err) => done(err));
    }
  )
);

passport.use(
  new FacebookStrategy(
    {
      clientID: process.env.FACEBOOK_APP_ID || "",
      clientSecret: process.env.FACEBOOK_APP_SECRET || "",
      callbackURL: `${process.env.BACKEND_BASE_URL}/v${
        version?.split(".")[0]
      }/api/auth/facebook/callback`,
      profileFields: ["first_name", "last_name", "email"],
    },
    (accessToken, refreshToken, profile, done) => {
      const firstName = profile._json.first_name;
      const lastName = profile._json.last_name;
      const email = profile._json.email || "";

      getUserByEmail(email)
        .then((user) => {
          if (user) {
            return done(null, user);
          } else {
            insertNewUser({ firstName, lastName, email, isVerified: true })
              .then(() => {
                getUserByEmail(email)
                  .then((newUser) => done(null, newUser))
                  .catch((err) => done(err));
              })
              .catch((err) => done(err));
          }
        })
        .catch((err) => done(err));
    }
  )
);

export default passport;
