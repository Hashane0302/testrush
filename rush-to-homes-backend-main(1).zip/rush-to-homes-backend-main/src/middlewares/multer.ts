import multer from "multer";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const path = "./public/images";
    fs.mkdirSync(path, { recursive: true });
    cb(null, path);
  },
  filename: (req, file, cb) => {
    const uuid = uuidv4();
    req.body.image = {
      fileId: uuid,
      fileName: `${uuid}.${file.originalname.split(".").pop()}`,
      url: `${process.env.BACKEND_BASE_URL}/public/images/${uuid}.${file.originalname.split(".").pop()}`
    };
    cb(null, `${uuid}.${file.originalname.split(".").pop()}`);
  }
});

const profileImgStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const path = "./public/profile-images";
    fs.mkdirSync(path, { recursive: true });
    cb(null, path);
  },
  filename: (req, file, cb) => {
    const uuid = uuidv4();
    req.body.image = {
      fileId: uuid,
      fileName: `${uuid}.${file.originalname.split(".").pop()}`,
      url: `${process.env.BACKEND_BASE_URL}/public/profile-images/${uuid}.${file.originalname.split(".").pop()}`
    };
    cb(null, `${uuid}.${file.originalname.split(".").pop()}`);
  }
});

const bannerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const path = "./public/banners";
    fs.mkdirSync(path, { recursive: true });
    cb(null, path);
  },
  filename: (req, file, cb) => {
    const uuid = uuidv4();
    req.body.image = {
      fileId: uuid,
      fileName: `${uuid}.${file.originalname.split(".").pop()}`,
      url: `${process.env.BACKEND_BASE_URL}/public/banners/${uuid}.${file.originalname.split(".").pop()}`
    };
    cb(null, `${uuid}.${file.originalname.split(".").pop()}`);
  }
});

export const upload = multer({ storage: storage });

export const profileImgUpload = multer({ storage: profileImgStorage });

export const bannerUpload = multer({ storage: bannerStorage });