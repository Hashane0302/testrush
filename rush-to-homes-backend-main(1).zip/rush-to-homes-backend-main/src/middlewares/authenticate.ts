import passport from "passport";
import { Request, Response, NextFunction } from "express";
import { getAdminByUserId } from "../repositories/user";
import jsonwebtoken, { JwtPayload } from "jsonwebtoken";
import _ from "lodash";

export const authenticate = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  passport.authenticate("jwt", { session: false }, (_err, user, _info) => {
    req.user = user;
    return next();
  })(req, res, next);
};

export const ensureAuthenticated = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  passport.authenticate("jwt", { session: false })(req, res, next);
};

export const ensureAdmin = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) return res.status(401).send({ isError: true, message: "User not authenticaed!" });
    
    const userId = (jsonwebtoken.decode(token) as JwtPayload).id;
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getAdminByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    if (!user.isAdmin) return res.sendStatus(403);

    next();
  } catch (err) {
    return res.sendStatus(403);
  }
};
