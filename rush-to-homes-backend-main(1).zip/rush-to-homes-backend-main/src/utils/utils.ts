import { Request } from "express";
import { Admin, FilterParams, User } from "../../types";
import _ from "lodash";
import jsonwebtoken from "jsonwebtoken";

export function filterParamsExtract(req: Request): FilterParams {
  const searchStr = req.query.searchStr
    ? req.query.searchStr.toString().split(" ")
    : [];

  const propertyTypes = (
    req.query.propertyTypes
      ? req.query.propertyTypes.toString().replace(/\[|\]/g, "").split(",")
      : []
  ).map((e) => e.trim().replace(/["']/g, ""));

  // const priceRangeType = _.get(
  //   req.query,
  //   "priceRangeType",
  //   "totalPrice"
  // ) as string;
  const priceRangeMin = req.query.priceRangeMin
    ? +req.query.priceRangeMin
    : undefined;
  const priceRangeMax = req.query.priceRangeMax
    ? +req.query.priceRangeMax
    : undefined;

  const district = _.get(req.query, "district", undefined) as string;
  const city = _.get(req.query, "city", undefined) as string;

  const landRangeType = _.get(
    req.query,
    "landAreaRangeType",
    "byPerch"
  ) as string;
  const landRangeMin = req.query.landRangeMin
    ? +req.query.landRangeMin
    : undefined;
  const landRangeMax = req.query.landRangeMax
    ? +req.query.landRangeMax
    : undefined;

  let sortBy;
  if (req.query.sortBy && req.query.sortBy === "price") sortBy = "price";
  else sortBy = "createdDate";

  let sortOrder: "ASC" | "DESC";
  if (req.query.sortOrder && req.query.sortOrder === "asc") sortOrder = "ASC";
  else sortOrder = "DESC";

  const searchType = _.get(req, "query.searchType", "") as string;

  return {
    searchStr,
    propertyTypes,
    // priceRangeType,
    priceRangeMin,
    priceRangeMax,
    district,
    city,
    landRangeType,
    landRangeMin,
    landRangeMax,
    sortBy,
    sortOrder,
    searchType,
  };
}

export function issueAccessToken(user: User | Admin): string {
  const payload = _.pick(user, [
    "id",
    "firstName",
    "lastName",
    "email",
    "countryCode",
    "phoneNumber",
    "isAdmin",
  ]);

  return jsonwebtoken.sign(payload, process.env.ACCESS_TOKEN_SECRET || "", {
    expiresIn: process.env.ACCESS_TOKEN_EXPIRE_TIME,
  });
}

export function issueRefreshToken(user: User | Admin): string {
  const payload = _.pick(user, [
    "id",
    "firstName",
    "lastName",
    "email",
    "countryCode",
    "phoneNumber",
    "isAdmin",
  ]);

  return jsonwebtoken.sign(payload, process.env.REFRESH_TOKEN_SECRET || "", {
    expiresIn: process.env.REFRESH_TOKEN_EXPIRE_TIME,
  });
}
