import { FieldInfo, MysqlError } from "mysql";
import { connection } from "./connect";

export const queryRunner = async (
  query: string,
  data: any[] = []
): Promise<any> => {
  return new Promise((resolve, reject) => {
    connection.query(
      query,
      data,
      (
        error: MysqlError | null,
        results: any,
        fields: FieldInfo[] | undefined
      ) => {
        // connection.end();
        if (error) reject(error);
        resolve({ results, fields });
      }
    );
  });
};
