import nodemailer, { SentMessageInfo, Transporter } from "nodemailer";
import path from "path";
import ejs from "ejs";

type Props = {
  replyTo?: { address: string; name: string };
  to: string;
  subject: string;
  text?: string;
  htmlPageName?: string;
  html?: string;
  replacements?: { [key: string]: string };
};

// async..await is not allowed in global scope, must use a wrapper
export async function sendMail({
  replyTo,
  to,
  subject,
  text,
  htmlPageName,
  html,
  replacements,
}: Props): Promise<SentMessageInfo> {
  // create reusable transporter object using the default SMTP transport
  const transporter: Transporter = nodemailer.createTransport({
    host: "mail.rushlankagroup.com",
    secure: false,
    tls: {
      rejectUnauthorized: false
    },
    port: 587,
    auth: {
      user: process.env.MAILER_EMAIL_ADDRESS, // generated ethereal user
      pass: process.env.MAILER_EMAIL_PASSWORD, // generated ethereal password
    },
  });

  let htmlToSend = "";
  if (htmlPageName) {
    htmlToSend = await ejs.renderFile(
      path.join(__dirname, `../email/${htmlPageName}/index.ejs`),
      {
        ...replacements,
        ...require(path.join(
          __dirname,
          `../email/${htmlPageName}/images/images.json`
        )),
      }
    );
  }

  // send mail with defined transport object
  return transporter.sendMail({
    from: {
      name: process.env.MAILER_NAME || "Rush To Home",
      address: process.env.MAILER_EMAIL_ADDRESS as string,
    },
    replyTo,
    to,
    subject,
    text,
    html: html || htmlToSend,
  });
}
