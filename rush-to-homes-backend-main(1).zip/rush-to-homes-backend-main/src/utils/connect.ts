import mysql, { Connection, MysqlError } from "mysql";
import dotenv from "dotenv";
dotenv.config();

export const connection: Connection = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USERNAME || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DATABASE || "rush_to_home",
});

export default function connect() {
  return new Promise((resolve, reject) => {
    connection.connect((err: MysqlError) => {
      if (err) {
        console.error("error connecting: " + err.stack);
        reject(err);
      }

      console.log("connected as id " + connection.threadId);
    });
  });
}
