/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { Request, Response } from "express";
import {
  advertisementCount,
  advertisementList,
  getAdvertisement,
  advertisementCitiesList,
  getAdvertisementListByIds,
  getAllAdvertisementListByPropertyType,
  reportAdd,
  createAdvertisement,
  getAllReportedAds,
  getAllAdsByAdmin,
  getAdByAdmin,
  updateAdByAdmin,
  getAdvertisementListByUser,
  updateAdvertisement,
  removeAdvertisement,
} from "../repositories/advertisement";
import { getUserByUserId, saveUserDetails } from "../repositories/user";
import { getDistrictAndCitiesList } from "../repositories/location";
import _ from "lodash";
import { filterParamsExtract } from "../utils/utils";
import { PropertyDataType } from "../../types";
import { PropertyMainMetadata } from "../metadata/property-main-metadata";
import Joi from "joi";
import { AdvertisementEntity, UserEntity } from "../entities";
import { adStatus } from "../metadata/ad-status";
import { saveRemark } from "../repositories/ad-remarks";

export const getAdvertisementCount = async (req: Request, res: Response) => {
  const filterParams = filterParamsExtract(req);
  const count = await advertisementCount(filterParams);
  return res.send({ count });
};

export const getAdvertisementList = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  const offset = req.query.offset
    ? parseInt(req.query.offset.toString())
    : undefined;
  const limit = req.query.limit
    ? parseInt(req.query.limit.toString())
    : undefined;

  const filterParams = filterParamsExtract(req);

  const dataList = await advertisementList(filterParams, limit, offset);

  const formattedAdvertisementList = dataList.map((e) => {
    return {
      ..._.pick(e, ["id", "title", "price", "priceUnit", "district", "city"]),
      image:
        e.images.length > 0
          ? {
              fileName: e.images[0].fileName,
              url: `${process.env.BACKEND_BASE_URL}/public/${e.images[0].locationUrl}`,
            }
          : {},
      ..._.pick(
        e,
        _.get(PropertyMainMetadata, e.propertyType, []).map((x) => x.key)
      ), // pick metadata by property type
      isSave: userId === undefined ? false : !!e.favoriteUsers.find((user) => user.id === +userId),
    };
  });

  return res.send(formattedAdvertisementList);
};

export const getAllAdvertisementCities = async (
  req: Request,
  res: Response
) => {
  try {
    const isAll = req.query.isAll;

    if (isAll === "true") {
      const locations = await getDistrictAndCitiesList();
      const formattedRes = _.mapValues(_.groupBy(locations, "nameEn"), (arr) =>
        _.map(arr[0].cities, "nameEn")
      );

      return res.send(formattedRes);
    } else {
      const results = await advertisementCitiesList();

      const formattedRes = _.mapValues(
        _.groupBy(_.orderBy(results, "district", "asc"), "district"),
        (arr) => _.uniq(arr.map((e) => e.city)).sort()
      );
      return res.send(formattedRes);
    }
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const getAdvertisementDetails = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  const advertisementId = +req.params.id;

  const advertisement = await getAdvertisement(advertisementId);
  if (!advertisement) return res.status(404).send();

  const propertyDetails: PropertyDataType = {
    ...advertisement,
    user: {
      userId: advertisement.user?.id,
      firstName: advertisement.user?.firstName,
      lastName: advertisement.user?.lastName,
      countryCode: advertisement.user?.countryCode,
      phoneNumber: advertisement.user?.phoneNumber,
    },
    propertyMainDetails: _.get(
      PropertyMainMetadata,
      advertisement.propertyType,
      []
    ).map((e: any) => {
      // @ts-ignore
      return { key: e.title, value: advertisement[e.key] };
    }),
    propertyFeatures: _.map(advertisement.propertyFeatures, "feature"),
    propertyDetails: { __html: advertisement.propertyDetails },
    images: advertisement.images.map((e) => ({
      fileName: e.fileName,
      url: `${process.env.BACKEND_BASE_URL}/public/${e.locationUrl}`,
    })),
    isSave: !!advertisement.favoriteUsers.find((user) => user.id === userId),
  };

  return res.send(propertyDetails);
};

export const reportAdvertisement = async (req: Request, res: Response) => {
  const schema = Joi.object({
    name: Joi.string().max(255).allow(""),
    email: Joi.string().email().required(),
    contactNumber: Joi.string().max(13).allow(""),
    reason: Joi.string().max(255).required(),
    details: Joi.string().max(255).required(),
  });

  const reportedAdd = {
    name: req.body.name,
    email: req.body.email,
    contactNumber: req.body.contactNumber,
    reason: req.body.reason,
    details: req.body.details,
  };

  const { error, value } = schema.validate(reportedAdd);

  if (error) {
    return res.status(406).json({
      message: error.message,
    });
  } else {
    await reportAdd({ ...value, advertisementId: +req.params.id });
    return res.sendStatus(201);
  }
};

export const getSimilarAd = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  const selectedAddId = req.query.advertisementId
    ? parseInt(req.query.advertisementId.toString())
    : undefined;
  const offset = req.query.offset
    ? parseInt(req.query.offset.toString())
    : undefined;
  const limit = req.query.limit
    ? parseInt(req.query.limit.toString())
    : undefined;
  const { sortBy, sortOrder } = filterParamsExtract(req);

  if (!selectedAddId) return res.send({ count: 0, similarAdList: [] });
  const selectedAd = await getAdvertisement(selectedAddId);
  if (!selectedAd) return res.send({ count: 0, similarAdList: [] });

  let samePropertyTypeAds = await getAllAdvertisementListByPropertyType(
    selectedAd.propertyType,
    selectedAd.offerType
  );

  samePropertyTypeAds = _.orderBy(
    samePropertyTypeAds.filter((e) => e.id !== selectedAd.id),
    sortBy,
    sortOrder === "ASC"
  ); // remove selected and sort

  if (samePropertyTypeAds.length === 0)
    return res.send({ count: 0, similarAdList: [] });

  const similarAdIdList: number[] = [];

  //same city
  similarAdIdList.push(
    ...samePropertyTypeAds
      .filter((e) => e.city === selectedAd.city)
      .map((e) => e.id)
  );

  //same district
  similarAdIdList.push(
    ...samePropertyTypeAds
      .filter(
        (e) =>
          e.district === selectedAd.district && !similarAdIdList.includes(e.id)
      )
      .map((e: { id: number }) => e.id)
  );

  //rest ads sort with price difference
  similarAdIdList.push(
    ..._.orderBy(
      samePropertyTypeAds
        .filter((e) => !similarAdIdList.includes(e.id))
        .map((e) => ({
          ...e,
          priceDifference: Math.abs(e.price - selectedAd.price),
        })),
      ["priceDifference"],
      ["asc"]
    ).map((e) => e.id)
  );

  const similarAdListUnordered = await getAdvertisementListByIds(
    similarAdIdList
  );

  const formatted = similarAdListUnordered.map((e) => {
    return {
      id: e.id,
      ..._.pick(e, ["title", "price", "district", "city"]),
      image:
        e.images.length > 0
          ? {
              fileName: e.images[0].fileName,
              url: `${process.env.BACKEND_BASE_URL}/public/${e.images[0].locationUrl}`,
            }
          : {},
      ..._.pick(
        e,
        _.get(PropertyMainMetadata, e.propertyType, []).map((x) => x.key)
      ), // pick metadata by property type
      isSave: !!e.favoriteUsers.find((user) => user.id === userId),
    };
  });

  const similarAdListOrdered = similarAdIdList
    .map((id) => formatted.find((ad) => ad.id == id))
    .filter((e) => e !== undefined);

  return res.send({
    count: similarAdListUnordered.length,
    similarAdList:
      offset !== undefined && limit !== undefined
        ? similarAdListOrdered
        : _.slice(similarAdListOrdered, offset, limit),
  });
};

export const saveAdvertisement = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  if (!userId) return res.sendStatus(401);

  const advertisementId = +req.params.id;

  const user = await getUserByUserId(userId);

  if (!user) return res.sendStatus(404);

  const isSaved = user.favoriteAds.find((e) => e.id === advertisementId);
  if (isSaved) {
    const newUser: UserEntity = {
      ...user,
      favoriteAds: user.favoriteAds.filter((e) => e.id !== advertisementId),
    };
    await saveUserDetails(newUser);
  } else {
    const advertisement = await getAdvertisement(advertisementId);
    if (advertisement) {
      const newUser = {
        ...user,
        favoriteAds: [...user.favoriteAds, advertisement],
      };
      await saveUserDetails(newUser);
    }
  }
  return res.send({ isSaved: !isSaved });
};

export const getSavedAds = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const favoriteAds = await getAdvertisementListByIds(user.favoriteAds.map(e => e.id));

    return res.status(200).send({ favoriteAds: favoriteAds.map(e => ({
      ...e,
      images: e.images.map((e) => ({
        fileName: e.fileName,
        url: `${process.env.BACKEND_BASE_URL}/public/${e.locationUrl}`,
      })),
    })) });
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const removeSavedAds = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const advertisementId = +req.params.id;

    const newUser: UserEntity = {
      ...user,
      favoriteAds: user.favoriteAds.filter((e) => e.id !== advertisementId),
    };
    await saveUserDetails(newUser);

    const favoriteAds = await getAdvertisementListByIds(newUser.favoriteAds.map(e => e.id));

    return res.status(200).send({ favoriteAds });
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const uploadImage = async (req: Request, res: Response) => {
  if (req.body.image) {
    return res.send(req.body.image);
  } else {
    return res.sendStatus(400);
  }
};

export const postAdvertisement = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const schema = Joi.object({
      propertyType: Joi.string().required(),
      adType: Joi.string().required(),
      district: Joi.string().required(),
      city: Joi.string().required(),
      address: Joi.string().required(),
      heading: Joi.string().required(),
      description: Joi.string().required(),
      price: Joi.number().min(1).required(), 
      priceInputType: Joi.string().required(), // ['totalPrice', 'perPerch', 'perAcre']
      landArea: Joi.when("propertyType", { not: "Apartments", then: Joi.number().min(1).required() }),
      landAreaInputType: Joi.string().required(), // ['perches', 'acres']
      rooms: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      bathrooms: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      floors: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      floorArea: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      parkingSpaces: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      propertyFeatures: Joi.array().items(Joi.string()),
      images: Joi.array().items(
        Joi.object({
          fileName: Joi.string(),
          fileId: Joi.string(),
        })
      ),
    });

    const postAd = { ...req.body };
    const { error, value } = schema.validate(postAd);

    if (error) {
      return res.status(406).json({ message: error.message });
    } else {
      const data: any = {
        userId: user.id,
        offerType: value.adType,
        propertyType: value.propertyType,
        // price: (function() {
        //   if (value.priceInputType === "perPerch") {
        //     if (value.landAreaInputType === "perches")
        //       return value.price * value.landArea;
        //     else return value.price * (value.landArea * 160);
        //   } else if (value.priceInputType === "perAcre") {
        //     if (value.landAreaInputType === "perches")
        //       return (value.price / 160) * value.landArea;
        //     else return value.price * value.landArea;
        //   } else {
        //     return value.price;
        //   }
        // })(),
        price: value.price,
        priceUnit: value.priceInputType,
        title: value.heading,
        bedroom: value.rooms,
        bathroom: value.bathrooms,
        floorArea: value.floorArea, //sqft
        floor: value.floors,
        carParkingSpace: value.parkingSpaces,
        landArea: (function() {
          if (value.landAreaInputType === "perches") return value.landArea;
          else return value.landArea * 160;
        })(),
        propertyDetails: value.description,
        district: value.district,
        city: value.city,
        propertyFeatures: value.propertyFeatures,
        images: (function() {
          return value.images.map((image: { fileName: string; fileId: any }) => {
            return {
              fileName: image.fileName,
              locationUrl: `images/${image.fileId}.${image.fileName
                .split(".")
                .pop()}`,
            };
          });
        })(),
      };
      await createAdvertisement(data);
      return res.sendStatus(201);
    }
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const editAdvertisement = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const advertisementId = +req.params.id;

    const advertisement = await getAdvertisement(advertisementId);
    if (!advertisement) return res.status(404).send({ isError: true, message: "Advertisement not found!" });

    const schema = Joi.object({
      propertyType: Joi.string().required(),
      adType: Joi.string().required(),
      district: Joi.string().required(),
      city: Joi.string().required(),
      address: Joi.string().required(),
      heading: Joi.string().required(),
      description: Joi.string().required(),
      price: Joi.number().min(1).required(), 
      priceInputType: Joi.string().required(), // ['totalPrice', 'perPerch', 'perAcre']
      landArea: Joi.when("propertyType", { not: "Apartments", then: Joi.number().min(1).required() }),
      landAreaInputType: Joi.string().required(), // ['perches', 'acres']
      rooms: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      bathrooms: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      floors: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      floorArea: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      parkingSpaces: Joi.when("propertyType", { not: "Land", then: Joi.number() }),
      propertyFeatures: Joi.array().items(Joi.string()),
      images: Joi.array().items(
        Joi.object({
          fileName: Joi.string(),
          fileId: Joi.string(),
        })
      ),
    });

    const { error, value } = schema.validate(req.body);

    if (error) {
      return res.status(406).json({ message: error.message });
    }

    const adData: AdvertisementEntity = {
      ...advertisement,
      offerType: value.adType,
      propertyType: value.propertyType,
      // price: (function() {
      //   if (value.priceInputType === "perPerch") {
      //     return value.landAreaInputType === "perches" ? value.price * value.landArea : value.price * (value.landArea * 160);
      //   } else if (value.priceInputType === "perAcre") {
      //     return value.landAreaInputType === "perches" ? (value.price / 160) * value.landArea : value.price * value.landArea;
      //   } else {
      //     return value.price;
      //   }
      // })(),
      price: value.price,
      priceUnit: value.priceInputType,
      title: value.heading,
      bedroom: value.rooms,
      bathroom: value.bathrooms,
      floorArea: value.floorArea, //sqft
      floor: value.floors,
      carParkingSpace: value.parkingSpaces,
      landArea: value.landAreaInputType === "perches" ? value.landArea : value.landArea * 160,
      propertyDetails: value.description,
      district: value.district,
      city: value.city,
      propertyFeatures: value.propertyFeatures,
      images: (function() {
        return value.images.map((image: { fileName: string; fileId: any }) => {
          return {
            fileName: image.fileName,
            locationUrl: `images/${image.fileId}.${image.fileName
              .split(".")
              .pop()}`,
          };
        });
      })(),
    };
    await updateAdvertisement(advertisementId, adData);

    return res.sendStatus(204);
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const deleteAdvertisement = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const advertisementId = +req.params.id;

    const advertisement = await getAdvertisement(advertisementId);
    if (!advertisement) return res.status(404).send({ isError: true, message: "Advertisement not found!" });

    if (advertisement.user.id !== user.id) return res.sendStatus(403);

    await removeAdvertisement(advertisementId);

    return res.sendStatus(204);
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const getManageAds = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const adList: {
      [key: string]: any[];
    } = {};

    const statusArr = ["active", "in review", "requested for amend", "rejected"];

    for (let i = 0; i < statusArr.length; i++ ) {
      const ads = await getAdvertisementListByUser(userId, adStatus[statusArr[i]]);
      adList[statusArr[i]] = ads.map(ad => ({
        ...ad,
        images: ad.images.map(e => ({
          fileName: e.fileName,
          url: `${process.env.BACKEND_BASE_URL}/public/${e.locationUrl}`,
        }))
      }));
    }

    return res.status(200).send(adList);
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const getAdListByAdmin = async (req: Request, res: Response) => {
  try {
    const offset = req.query.offset
      ? parseInt(req.query.offset.toString())
      : 0;
    const limit = req.query.limit
      ? parseInt(req.query.limit.toString())
      : 10;
    const searchTerm = (req.query.q?.toString() || "")
      .split(",")
      .filter(e => !!e)
      .map(e => e.split(":") as [string, string])
      .filter(e => !!e[1]);

    if (req.query?.status?.toString() === "reported") {
      const allreportedAds = await getAllReportedAds(offset, limit, searchTerm);
      return res.status(200).send({ allreportedAds });
    }

    const status = req.query?.status?.toString() === "all" ? "all" : adStatus[req.query?.status?.toString() || "active"];

    const ads = await getAllAdsByAdmin(offset, limit, status, searchTerm);
    return res.status(200).send({ ads });
  } catch (err) {
    const error = err as any;
    return res.status(400).send({ isError: true, message: error.message || "Something went wrong" });
  }
};

export const getAdvertisementDetailsByAdmin = async (req: Request, res: Response) => {
  try {
    const advertisementId = +req.params.id;

    const advertisement = await getAdByAdmin(advertisementId);
    if (!advertisement)
      return res.status(404).send({ isError: true, message: "Advertisement not found!" });

    return res.status(200).send({
      ...advertisement,
      id: advertisementId,
      user: {
        userId: advertisement.user?.id,
        firstName: advertisement.user?.firstName,
        lastName: advertisement.user?.lastName,
        countryCode: advertisement.user?.countryCode,
        phoneNumber: advertisement.user?.phoneNumber,
      },
      propertyMainDetails: _.get(
        PropertyMainMetadata,
        advertisement.propertyType,
        []
      ).map((e: any) => {
        // @ts-ignore
        return { key: e.title, value: advertisement[e.key] };
      }),
      propertyFeatures: _.map(advertisement.propertyFeatures, "feature"),
      propertyDetails: { __html: advertisement.propertyDetails },
      images: advertisement.images.map((e) => ({
        fileName: e.fileName,
        url: `${process.env.BACKEND_BASE_URL}/public/${e.locationUrl}`,
      })),
    });
  } catch (err) {
    const error = err as any;
    return res.status(400).send({ isError: true, message: error.message || "Something went wrong" });
  }
};

export const changeStatusAd = async (req: Request, res: Response) => {
  try {
    const advertisementId = +req.params.id;
    const advertisement = await getAdByAdmin(advertisementId);
    if (!advertisement)
      return res.status(404).send({ isError: true, message: "Advertisement not found!" });

    const { newStatus, remarks } = req.body;

    if (!newStatus) return res.status(400).send({ isError: true, message: "New status is required" });
    const status = adStatus[newStatus as string || "draft"];

    // status automata
    if ((status === 2 || status === 3) && advertisement.status !== 1)
      return res.status(400).send({ isError: true, message: `Previous status should be 'in review' to change new status to '${newStatus}'` });
    if (status === 5 && advertisement.status !== 3)
      return res.status(400).send({ isError: true, message: "Previous status should be 'active' to change new status to 'rejected'" });

    if (status === 2 || status === 5) {
      if (!remarks) return res.status(400).send({ isError: true, message: "New status is required" });
      await saveRemark({ remark: remarks, status, advertisement });
    }

    await updateAdByAdmin(advertisementId, { status });
    return res.status(204).send();
  } catch (err) {
    const error = err as any;
    return res.status(400).send({ isError: true, message: error.message || "Something went wrong" });
  }
};
