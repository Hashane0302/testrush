import { Request, Response } from "express";
import {
  saveMessage,
  fetchConversationId,
  fetchConversations,
  fetchBetweenConversation,
  updateMessageReadStatus,
  getConversationById,
  getConversationByAdId,
  saveConversation } from "../repositories/messages";
import Joi from "joi";
import _ from "lodash";
import { getUserByUserId } from "../repositories/user";
import { ConversationEntity } from "../entities/conversation.entity";
import { getAdvertisement } from "../repositories/advertisement";

export const addMessages = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const { convId, text, adId } = req.body;

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    let conversation: ConversationEntity | null;

    if (convId) {
      conversation = await getConversationById(+convId);
    } else {
      const ad = await getAdvertisement(adId);

      if (!ad || !ad.user) return res.status(406).send({ isError: true, message: "Invalid request" });

      conversation = new ConversationEntity();
      conversation.users = [user, ad.user];
      conversation.ad = ad;
      conversation = await saveConversation(conversation);
    }

    if (!conversation) return res.status(404).send({ isError: true, message: "Conversation not found!" });

    const newMsg = await saveMessage({
      conversation,
      user,
      text
    });
    return res.status(201).json(newMsg);
  } catch (error) {
    return res.status(500).json(error);
  }
};

export const getAdConversation = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

  const schema = Joi.object({
    adId: Joi.number().required()
  });

  const { error, value } = schema.validate(req.params);

  if (error) {
    return res.status(406).send({ isError: true, message: error.message || "Something went wrong" });
  }

  try {
      const conv = await getConversationByAdId(value.adId, userId);

      return res.send({ conv });
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong" });
  }
};

export const getBetweenConversation = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

  const schema = Joi.object({
    conversationId: Joi.number().required()
  });

  const { error, value } = schema.validate(req.params);

  try {
    if (error) {
      return res.status(406).json({ isError: true, message: error.message });
    } else {
      const fetchedMessages = await fetchBetweenConversation(value.conversationId, +userId);
      return res.send(fetchedMessages);
    }
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong" });
  }
};

export const getMessageList = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const isChatPage = req.query.isChatPage?.toString() === "true";
    const conversationIds = (await fetchConversationId(userId)).map(e => e.id);

    const fetchedMessages = await fetchConversations(conversationIds);

    const count = fetchedMessages.filter(e => e.messages[e.messages.length - 1].read === false).length;

    return res.status(200).send(isChatPage ? {
      count,
      msgList: fetchedMessages.map(e => ({
        ...e,
        users: e.users.find(f => f.id !== userId),
        ad: {
          ...e.ad,
          images: e.ad.images[e.ad.images.length - 1]
        },
        messages: e.messages[e.messages.length - 1]
      }))
    } : { count });
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const updateMsg = async (req: Request, res: Response) => {
  try {
    const { msgId, convId, otherUserId } = req.body;

    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

    if (!msgId || !convId || !otherUserId) {
      return res.status(406).json({ isError: true, message: "Invalid request" });
    }

    await updateMessageReadStatus(+msgId, +convId, +otherUserId);
    return res.sendStatus(204);
  } catch (error) {
    return res.status(400).send({ isError: true, message: (error as any).message || "Something went wrong" });
  }
};
