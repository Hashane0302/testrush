import { Request, Response } from "express";
import { BannerEntity } from "../entities";
import { bannerList, deleteBanner, getBanner, saveBanner, updateBannerViews } from "../repositories/banner";

export const getBannerList = async (req: Request, res: Response) => {
  const searchStr = req.query.searchStr ? req.query.searchStr.toString().split(" ") : [];

  const offset = +(req.query.offset?.toString() || 0);
  const limit = +(req.query.limit?.toString() || 0);
  const isAdmin = req.query.isAdmin?.toString();

  const list = await bannerList(searchStr, limit, offset);
  const bannerIds = (list as any[]).map(e => e.id);

  if (isAdmin !== "true") await updateBannerViews(bannerIds);
  return res.status(200).send(list);
};

export const addBanner = async (req: Request, res: Response) => {
  if (!req.body.image) return res.sendStatus(400);

  try {
    const { fileName, url } = req.body.image;

    if (!url) return res.status(404).json({ isError: true, message: "Banner URL not found!" });

    let banner = { fileName, locationUrl: url } as BannerEntity;
    banner = await saveBanner(banner);

    return res.status(200).send({ message: "Banner added successfully!", banner });
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong", error });
  }
};

export const removeBanner = async (req: Request, res: Response) => {
  if (!req.params.id) return res.sendStatus(400);

  try {
    const banner = await getBanner(+req.params.id);
    if (!banner) return res.status(404).send({ isError: true, message: "Banner not found!" });

    await deleteBanner(banner);

    return res.status(200).send({ message: "Banner removed successfully!", banner });
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong", error });
  }
};
