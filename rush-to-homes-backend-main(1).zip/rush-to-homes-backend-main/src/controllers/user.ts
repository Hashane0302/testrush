import { Request, Response } from "express";
import { deleteUser, getAdmins, getUsers, deleteAdmin, getUserByUserId, saveUserDetails } from "../repositories/user";
import _ from "lodash";
import { UserEntity } from "../entities";

export const getUser = async (req: Request, res: Response) => {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    return res.status(200).send(user);
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const getAllAdmins = async (req: Request, res: Response) => {
  const admins = await getAdmins();
  return res.status(200).send(admins);
};

export const getAllUsers = async (req: Request, res: Response) => {
  const users = await getUsers();
  return res.status(200).send(users);
};

export const deleteAUser = async (req: Request, res: Response) => {
  try {
    const users = await deleteUser(req.body.id);
    return res.status(200).send(users);
  } catch (error) {
    return res.status(401).send(error);
  }
};

export const deleteAnAdmin = async (req: Request, res: Response) => {
  try {
    const users = await deleteAdmin(req.body.id);
    return res.status(200).send(users);
  } catch (error) {
    return res.status(401).send(error);
  }
};

export const updateProfile = async (req: Request, res: Response) => {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    let user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    user = { ...user, ...req.body } as UserEntity;

    await saveUserDetails(user);

    return res.sendStatus(204);
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const uploadProfileImage = async (req: Request, res: Response) => {
  if (req.body.image) {
    return res.send(req.body.image);
  } else {
    return res.sendStatus(400);
  }
};