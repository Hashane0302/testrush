/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { NextFunction, Request, Response } from "express";
import {
  getUserByEmail,
  insertNewUser,
  getUserByUserId,
  updateUserStatus,
  saveUserDetails,
  getUserIdByEmail,
  getUserIdByPhoneNumber,
  insertNewAdmin,
  getAdminByEmail,
  getAdminByUserId,
  getUserWithPassword,
  getUserByPassword,
} from "../repositories/user";
import Joi from "joi";
import _ from "lodash";
import bcrypt from "bcrypt";
import jsonwebtoken, { JwtPayload } from "jsonwebtoken";
import passport, { use } from "passport";
import queryString from "query-string";
import { sendMail } from "../utils/mailer";
import { sendOTP, verifyOTP } from "../api/shoutout.api";
import { issueAccessToken, issueRefreshToken } from "../utils/utils";
import { accountActivationEmail, passwordResetEmail } from "../email/emailContents";
import version from "../version";
import { AdditionalPhoneNumberEntity } from "../entities";
import { getAdditionalPhoneById, saveAdditionalPhone } from "../repositories/additional-phone-number";

const refreshTokens: string[] = [];

export const signUp = async (req: Request, res: Response) => {
  const schema = Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    password: Joi.string().required(),
    email: Joi.string().required().email(),
    countryCode: Joi.string().required(),
    phoneNumber: Joi.string().required(),
  });

  const userData = _.pick(req.body, [
    "firstName",
    "lastName",
    "password",
    "email",
    "countryCode",
    "phoneNumber",
  ]);

  const { error, value } = schema.validate(userData);

  if (error)
    return res.status(400).send({ isError: true, message: "Validation error" });

  try {
    const existUserForEmail = await getUserByEmail(value.email);

    if (existUserForEmail)
      return res.status(400).send({
        isError: true,
        message: "This email address already registered.",
      });

    if (await getUserIdByPhoneNumber(value.phoneNumber)) {
      return res
        .status(400)
        .send({ isError: true, message: "This phone number already exists" });
    }

    const hashPassword = await bcrypt.hash(value.password, 10);

    // send verification link

    const tokenSecret: any = process.env.ACCESS_TOKEN_SECRET;
    const tokenExpireTime = "1d";

    const signedToken = jsonwebtoken.sign(
      {
        user: value.email,
      },
      tokenSecret,
      {
        expiresIn: tokenExpireTime,
      }
    );

    const url = `${process.env.BACKEND_BASE_URL}/v${
      version?.split(".")[0]
    }/api/auth/confirmation/${signedToken}`;

    const response = await sendMail({
      to: value.email,
      subject: "Rush 2 Homes - Regarding “Heading”",
      html: accountActivationEmail(url)
    });

    if (response.rejected.length > 0)
      return res.send({ isError: true, message: "Email send fail" });
    else
      await insertNewUser({
        firstName: value.firstName,
        lastName: value.lastName,
        password: hashPassword,
        email: value.email,
        countryCode: value.countryCode,
        phoneNumber: value.phoneNumber,
        isVerifed: true,
      });
    res
      .status(200)
      .send({ isError: false, message: "Registration Successful" });
  } catch (error: any) {
    return res.status(500).send({ isError: true, message: error.message });
  }
};

export const signIn = async (req: Request, res: Response) => {
  if (!req.user) return res.sendStatus(401);

  const accessToken = issueAccessToken(req.user);
  const refreshToken = issueRefreshToken(req.user);

  return res.status(200).send({ accessToken, refreshToken });
};

export const renewAccessToken = async (req: Request, res: Response) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken || !jsonwebtoken.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET || "")) {
      return res.sendStatus(401);
    }
    // @ts-ignore
    const decoded = jsonwebtoken.decode(refreshToken) as JwtPayload;
    const user = await (decoded.isAdmin ? getAdminByUserId(decoded.id) : getUserByUserId(decoded.id));
    if (!user) return res.sendStatus(401);

    // @ts-ignore
    const accessToken = issueAccessToken(user);

    return res.send({ accessToken });
  } catch(err) {
    return res.status(401).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const test = async (_req: Request, res: Response) => {
  const result = await sendOTP("94766431915");
  return res.json(result.data);
};

export const googleAuthCallback = (req: Request, res: Response) => {
  passport.authenticate(
    "google",
    {
      session: false,
      failureRedirect: `${process.env.FRONTEND_APP_BASE_URL}`,
    },
    (err, user, _info) => {
      if (err) {
        return res.redirect(`${process.env.FRONTEND_APP_BASE_URL}`);
      }
      if (user) {
        const signedToken = jsonwebtoken.sign(
          {
            userId: user.id,
            isEmailVerified: true,
            isHaveMobileNumber: !!user.phoneNumber,
            isPhoneNoVerified: user.isPhoneNoVerified,
          },
          process.env.ACCESS_TOKEN_SECRET || "secret",
          { expiresIn: "5m" }
        );
        const stringified = queryString.stringify({ token: signedToken });
        return res.redirect(
          `${process.env.FRONTEND_APP_BASE_URL}/auth-callback?${stringified}`
        );
      }
    }
  )(req, res);
};

export const facebookAuthCallback = (req: Request, res: Response) => {
  passport.authenticate(
    "facebook",
    {
      session: false,
      failureRedirect: `${process.env.FRONTEND_APP_BASE_URL}`,
    },
    (err, user, _info) => {
      if (err) {
        return res.redirect(`${process.env.FRONTEND_APP_BASE_URL}`);
      }
      if (user) {
        const signedToken = jsonwebtoken.sign(
          {
            userId: user.id,
            isEmailVerified: true,
            isHaveMobileNumber: !!user.phoneNumber,
            isPhoneNoVerified: user.isPhoneNoVerified,
          },
          process.env.ACCESS_TOKEN_SECRET || "secret",
          { expiresIn: "5m" }
        );
        const stringified = queryString.stringify({ token: signedToken });
        // tokens.push({ id: user.id, token: confirmToken });
        return res.redirect(
          `${process.env.FRONTEND_APP_BASE_URL}/auth-callback?${stringified}`
        );
      }
    }
  )(req, res);
};

export const authTokenConfirmCallback = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { token } = req.body;
  if (!jsonwebtoken.verify(token, process.env.ACCESS_TOKEN_SECRET || "secret"))
    return res.sendStatus(401);

  // @ts-ignore
  const { userId } = jsonwebtoken.decode(token);

  const user = await getUserByUserId(userId);
  if (!user) return res.sendStatus(401);
  req.user = user;

  next();
};

export const verifyToken = async (req: Request, res: Response) => {
  const tokenSecret: any = process.env.ACCESS_TOKEN_SECRET;
  try {
    const { user }: any = jsonwebtoken.verify(req.params.token, tokenSecret);
    const userObj = await getUserIdByEmail(user);

    if (!userObj) return res.sendStatus(401);
    userObj.isVerified = true;

    await updateUserStatus(user);

    const signedToken = jsonwebtoken.sign(
      {
        userId: userObj.id,
        isEmailVerified: true,
        isHaveMobileNumber: !!userObj.phoneNumber,
        isPhoneNoVerified: userObj.isPhoneNoVerified,
        isAdmin: userObj.isAdmin,
      },
      process.env.ACCESS_TOKEN_SECRET || "secret",
      { expiresIn: "5m" }
    );

    const stringified = queryString.stringify({ token: signedToken });
    return res.redirect(
      `${process.env.FRONTEND_APP_BASE_URL}/auth-callback?${stringified}`
    );
  } catch (error) {
    return res.sendStatus(401);
  }
};

export const verifyAdmin = async (req: Request, res: Response) => {
  const user = await getAdminByUserId(parseInt(req.body.userId));
  if (!user) return res.sendStatus(401);
  if (!user.isAdmin) return res.sendStatus(401);
  return res.sendStatus(200);
};

export const sendOTPCode = async (req: Request, res: Response) => {
  const { userId } = req.body;
  const user = await getUserByUserId(userId);
  if (!user) return res.status(404).send({ message: "User not found" });

  try {
    const otpResult = await sendOTP(`${user.countryCode}${user.phoneNumber}`);
    user.otpReferenceId = otpResult.data.referenceId;
    await saveUserDetails(user);
    return res
      .status(200)
      .send({ message: "OTP code has been sent to your phone number" });
  } catch (err) {
    return res.status(500).send({ message: "OTP sent failed" });
  }
};

export const verifyPhoneNumber = async (req: Request, res: Response) => {
  const { userId, code } = req.body;
  const user = await getUserByUserId(userId);

  if (!user) return res.status(404).send({ message: "User not found" });
  if (!user.otpReferenceId)
    return res
      .status(404)
      .send({ message: "An OTP code not have been sent to you" });

  try {
    const result = await verifyOTP(code, user.otpReferenceId);
    // const result = {data: {statusCode:"1000", description: "test"}}
    if (result.data.statusCode === "1000") {
      user.isPhoneNoVerified = true;
      user.otpReferenceId = "";
      await saveUserDetails(user);
      return res.status(200).send({
        message: "Your phone number has been verified",
        description: result.data.description,
      });
    } else {
      return res.status(400).send({
        message: "Verification failed",
        description: result.data.description,
      });
    }
  } catch (err) {
    return res.status(400).send({ message: "Verification failed" });
  }
};

export const updatePhoneNumber = async (req: Request, res: Response) => {
  const { userId, countryCode, phoneNumber } = req.body;

  const schema = Joi.object({
    countryCode: Joi.string().required(),
    phoneNumber: Joi.string().required(),
  });

  const { error, value } = schema.validate({ countryCode, phoneNumber });

  if (error) return res.status(400).send({ message: "Validation error" });

  if (await getUserIdByPhoneNumber(phoneNumber)) {
    return res
      .status(400)
      .send({ message: "This phone number already exists" });
  }

  const user = await getUserByUserId(userId);
  if (!user) {
    return res.status(400).send({ message: "User not found" });
  }

  user.countryCode = value.countryCode;
  user.phoneNumber = value.phoneNumber;

  await saveUserDetails(user);

  return res.sendStatus(200);
};

export const addAdmin = async (req: Request, res: Response) => {
  const schema = Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    password: Joi.string().required(),
    email: Joi.string().required().email(),
    countryCode: Joi.string().required(),
    phoneNumber: Joi.string().required(),
  });

  const userData = _.pick(req.body, [
    "firstName",
    "lastName",
    "password",
    "email",
    "countryCode",
    "phoneNumber",
  ]);

  const { error, value } = schema.validate(userData);

  if (error)
    return res.status(400).send({ isError: true, message: "Validation error" });

  try {
    const hashPassword = await bcrypt.hash(value.password, 10);

    await insertNewAdmin({
      firstName: value.firstName,
      lastName: value.lastName,
      password: hashPassword,
      email: value.email,
      countryCode: value.countryCode,
      phoneNumber: value.phoneNumber,
      isVerified: true,
      isAdmin: true,
    });
    res
      .status(200)
      .send({ isError: false, message: "New Admin Added Successfully" });
  } catch (error: any) {
    console.log(error);
    return res.status(500).send({ isError: true, message: error.message });
  }
};

export const signInAdmin = async (req: Request, res: Response) => {
  if (!req.body) return res.sendStatus(401);

  await getAdminByEmail(req.body.email)
    .then(async (user) => {
      if (!user) return res.sendStatus(401);
      if (!(await bcrypt.compare(req.body.password, user.password)))
        return res.sendStatus(401);

      const accessToken = issueAccessToken(user);
      const refreshToken = issueRefreshToken(user);
      refreshTokens.push(refreshToken);
      return res.status(200).send({ accessToken, refreshToken });
    })
    .catch(() => {
      return res.sendStatus(401);
    });
};

export const changePassword = async (req: Request, res: Response) => {
  try {
    const userId = _.get(req, "user.id", undefined);
    if (!userId) return res.status(401).send({ isError: true, message: "User not authenticaed!" });

    const user = await getUserWithPassword(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const schema = Joi.object({
      password: Joi.string().required(),
      newPassword: Joi.string().required()
    });

    const userData = _.pick(req.body, ["password", "newPassword"]);
  
    const { error, value } = schema.validate(userData);
  
    if (error)
      return res.status(400).send({ isError: true, message: error.message || "Validation error" });

    if (value.password === value.newPassword)
      return res.status(400).send({ isError: true, message: "New password and old password cannot be same." });

    const match = await bcrypt.compare(value.password, user.password);

    if (!match) {
      return res.status(400).send({ isError: true, message: "Current password mismatched. Try again!" });
    }

    const hashPassword = await bcrypt.hash(value.newPassword, 10);

    await saveUserDetails({
      ...user,
      password: hashPassword
    });

    return res.status(204).send({ message: "Password updated successfully" });
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong" });
  }
};

export const forgotPassword = async (req: Request, res: Response) => {
  try {
    const schema = Joi.object({
      email: Joi.string().required()
    });
  
    const { error, value } = schema.validate(req.body);
  
    if (error)
      return res.status(400).send({ isError: true, message: error.message || "Validation error" });

    const user = await getUserByEmail(value.email);
    if (user) {
      sendMail({
        to: value.email,
        subject: "Rush 2 Homes - Password Reset",
        html: passwordResetEmail(user.firstName, Buffer.from(user.password).toString("base64"))
      });
    }
  } catch (err) {/* */}

  return res.status(200).send({ message: "Password reset link sent successfully" });
};

export const validateResetPassword = async (req: Request, res: Response) => {
  try {
    const schema = Joi.object({
      token: Joi.string().required()
    });
  
    const { error, value } = schema.validate(req.body);
  
    if (error)
      return res.status(400).send({ isError: true, message: error.message || "Validation error" });

    const user = await getUserByPassword(Buffer.from(value.token, "base64").toString());
    if (!user) return res.status(400).send({ isError: true, message: "Invalid token" });

    return res.sendStatus(200);
  } catch (err) {
    return res.status(400).send({ isError: true, message: "Invalid token" });
  }
};

export const resetPassword = async (req: Request, res: Response) => {
  try {
    const schema = Joi.object({
      token: Joi.string().required(),
      password: Joi.string().required()
    });
  
    const { error, value } = schema.validate(req.body);
  
    if (error)
      return res.status(400).send({ isError: true, message: error.message || "Validation error" });

    const user = await getUserByPassword(Buffer.from(value.token, "base64").toString());
    if (!user) return res.status(400).send({ isError: true, message: "Invalid token" });

    const compare = bcrypt.compareSync(value.password, user.password);
    if (compare) return res.status(400).send({ isError: true, message: "New password cannot be same as previous password" });

    user.password = bcrypt.hashSync(value.password, 10);
    await saveUserDetails(user);

    return res.status(200).send({ message: "Password reset successfully!" });
  } catch (err) {
    return res.status(400).send({ isError: true, message: (err as any).message || "Something went wrong, Please try again!" });
  }
};