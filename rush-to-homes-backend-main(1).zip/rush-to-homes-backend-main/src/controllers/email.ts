import { Request, Response } from "express";
import { getAdvertisement } from "../repositories/advertisement";
import Joi from "joi";
import _ from "lodash";
import { sendMail } from "../utils/mailer";

export const sendEmailToAdvertiser = async (req: Request, res: Response) => {
  const schema = Joi.object({
    name: Joi.string().required(),
    email: Joi.string().email().required(),
    contactNumber: Joi.string().required(),
    message: Joi.string().required(),
  });

  const { error, value } = schema.validate(
    _.pick(req.body, ["name", "email", "contactNumber", "message"])
  );

  if (error) return res.send({ isError: true, message: "Validation error" });

  try {
    const advertisement = await getAdvertisement(req.body.propertyId);
    if (!advertisement) return res.sendStatus(404);

    const response = await sendMail({
      replyTo: { address: value.email, name: value.name },
      to: advertisement.user.email,
      subject: `Rush 2 Homes - Regarding “${advertisement.title}”`,
      text: `Name: ${value.name}\nEmail Address: ${value.email}\nContact Number: ${value.contactNumber}\n\nMessage: ${value.message}`,
    });

    if (response.rejected.length > 0)
      return res.send({ isError: true, message: "Email send fail" });
    else return res.send({ isError: false, message: "Email send successful" });
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } catch (e: any) {
    return res.send({ isError: true, message: e.message });
  }
};
