import { Request, Response } from "express";
import Joi from "joi";
import _ from "lodash";
import { sendOTP, verifyOTP } from "../api/shoutout.api";
import { AdditionalPhoneNumberEntity } from "../entities";
import { deleteAdditionalPhone, getAdditionalPhoneById, getAdditionalPhoneByNumber, getAdditionalPhoneByUser, saveAdditionalPhone } from "../repositories/additional-phone-number";
import { getUserByUserId } from "../repositories/user";

export const sendOTPToAdditionalPhone = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

  const schema = Joi.object({
    countryCode: Joi.string().required(),
    phoneNumber: Joi.string().required().length(9)
  });

  const { error, value } = schema.validate(req.body);

  if (error) {
    return res.status(406).send({ isError: true, message: error.message || "Something went wrong" });
  }

  try {
    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    if (`${user.countryCode}${user.phoneNumber}` === `${value.countryCode}${value.phoneNumber}`)
      return res.status(400).send({ isError: true, message: "Cannot add primary Phone number as a additional Phone number!" });

    const phone = await getAdditionalPhoneByNumber(value.countryCode, value.phoneNumber);
    if (phone) return res.status(400).send({ isError: true, message: "Cannot add exisiting Phone number as a additional Phone number!" });

    const otpResult = await sendOTP(`${value.countryCode}${value.phoneNumber}`);

    let additionalPhone = {
      countryCode: value.countryCode,
      phoneNumber: value.phoneNumber,
      otpReference: otpResult.data.referenceId,
      user: user,
      verified: false
    } as AdditionalPhoneNumberEntity;

    additionalPhone = await saveAdditionalPhone(additionalPhone);

    return res.status(200).send({ message: "OTP code has been sent to your phone number", additionalPhone });
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong", error });
  }
};

export const resendOTPToAdditionalPhone = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

  const schema = Joi.object({
    phoneId: Joi.number().required(),
  });

  const { error, value } = schema.validate(req.params);

  if (error) {
    return res.status(406).send({ isError: true, message: error.message || "Something went wrong" });
  }

  try {
    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    let phone = await getAdditionalPhoneById(value.phoneId);
    if (!phone) return res.status(404).send({ isError: true, message: "Additional Phone not found!" });

    if (phone.user.id !== user.id) return res.status(403).send({ isError: true, message: "Unauthorized" });

    const otpResult = await sendOTP(`${phone.countryCode}${phone.phoneNumber}`);
    phone.otpReference = otpResult.data.referenceId;

    phone = await saveAdditionalPhone(phone);

    return res.status(200).send({ message: "OTP code has been resent to your phone number", phone });
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong", error });
  }
};

export const verifyAdditionalPhone = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

  const schema = Joi.object({
    phoneId: Joi.number().required(),
    code: Joi.string().required().min(5)
  });

  const { error, value } = schema.validate(req.body);

  if (error) {
    return res.status(406).send({ isError: true, message: error.message || "Something went wrong" });
  }

  try {
    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const phone = await getAdditionalPhoneById(value.phoneId);
    if (!phone) return res.status(404).send({ isError: true, message: "Additional Phone not found!" });

    if (phone.user.id !== user.id) return res.status(403).send({ isError: true, message: "Unauthorized" });

    if (!phone.otpReference) return res.status(400).send({ isError: true, message: "An OTP code not have been sent to you" });

    const result = await verifyOTP(value.code, phone.otpReference);

    if (result.data.statusCode == "1000") {
      phone.otpReference = "";
      phone.verified = true;

      await saveAdditionalPhone(phone);
      return res.status(200).send({ message: "Your phone number has been verified" });
    }
    
    return res.status(400).send({ isError: true, message: "Verification failed. Please try again", data: result.data });
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong", error });
  }
};

export const getAdditionalPhones = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

  try {
    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const phones = await getAdditionalPhoneByUser(user.id);
    
    return res.status(200).send({ phones, message: "Additional phones retrived successfully" });
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong", error });
  }
};

export const removeAdditionalPhone = async (req: Request, res: Response) => {
  const userId = _.get(req, "user.id", undefined);
  if (!userId) return res.status(401).send({ isError: true, message: "User not authenticated!" });

  const schema = Joi.object({
    phoneId: Joi.number().required(),
  });

  const { error, value } = schema.validate(req.params);

  if (error) {
    return res.status(406).send({ isError: true, message: error.message || "Something went wrong" });
  }

  try {
    const user = await getUserByUserId(userId);
    if (!user) return res.status(404).send({ isError: true, message: "User not found!" });

    const phone = await getAdditionalPhoneById(value.phoneId);
    if (!phone) return res.status(404).send({ isError: true, message: "Additional Phone not found!" });

    if (phone.user.id !== user.id) return res.status(403).send({ isError: true, message: "Unauthorized" });

    await deleteAdditionalPhone(phone);
    return res.sendStatus(204);
  } catch (error) {
    return res.status(400).json({ isError: true, message: (error as any).message || "Something went wrong", error });
  }
};