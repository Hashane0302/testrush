/* eslint-disable @typescript-eslint/no-explicit-any */
import { Request, Response } from "express";
import { getAllCategoryList, getCategoryById, getCategoryByName, removeCategory, saveCategory, updateCategoryData } from "../repositories/category";

export const addCategory = async (req: Request, res: Response) => {
  const data = req.body;

  try {
    const category = await getCategoryByName(data);
    if (category) 
      return res
        .status(409)
        .send({ isError: true, message: "Category from this name already exists" });

    const { adGroup, additionalDetails, propertyFeatures, ...categoryData } = data;

    const newCategory = await saveCategory({
      ...categoryData,
      adGroup: JSON.stringify(adGroup),
      additionalDetails: JSON.stringify(additionalDetails),
      propertyFeatures: JSON.stringify(propertyFeatures || [])
    });

    return res.status(201).send(newCategory);
  } catch (error) {
    return res.status(400).send({ isError: true, message: (error as any).message || "Something went wrong" });
  }
};

export const getAllCategories = async (req: Request, res: Response) => {
  try {
    const offset = req.query.offset
      ? parseInt(req.query.offset.toString())
      : 0;
    const limit = req.query.limit
      ? parseInt(req.query.limit.toString())
      : 10;

    const categories = await getAllCategoryList(offset, limit);

    return res.status(200).send({
      categories: categories.map(e => ({
        ...e,
        adGroup: JSON.parse(e.adGroup),
        additionalDetails: JSON.parse(e.additionalDetails),
        propertyFeatures: JSON.parse(e.propertyFeatures),
      }))
    });
  } catch (error) {
    return res.status(400).send({ isError: true, message: (error as any).message || "Something went wrong" });
  }
};

export const getCategory = async (req: Request, res: Response) => {
  try {
    const id = +req.params.id;

    const category = await getCategoryById(id);
    if (!category)
      return res.status(404).send({ isError: true, message: "Category not found!" });

    const { adGroup, additionalDetails, propertyFeatures, ...categoryData } = category;

    return res.status(200).send({
      ...categoryData,
      adGroup: JSON.parse(adGroup),
      additionalDetails: JSON.parse(additionalDetails),
      propertyFeatures: JSON.parse(propertyFeatures)
    });
  } catch (error) {
    return res.status(400).send({ isError: true, message: (error as any).message || "Something went wrong" });
  }
};

export const updateCategory = async (req: Request, res: Response) => {
  try {
    const id = +req.params.id;
    const data = req.body;

    const category = await getCategoryById(id);
    if (!category)
      return res.status(404).send({ isError: true, message: "Category not found!" });

    if (!data)
      return res.status(400).send({ isError: true, message: "Category data is required" });

    const { adGroup, additionalDetails, propertyFeatures, ...categoryData } = data;

    await updateCategoryData(id, {
      ...categoryData,
      adGroup: JSON.stringify(adGroup),
      additionalDetails: JSON.stringify(additionalDetails),
      propertyFeatures: JSON.stringify(propertyFeatures || [])
    });

    return res.status(204).send();
  } catch (error) {
    return res.status(400).send({ isError: true, message: (error as any).message || "Something went wrong" });
  }
};

export const deleteCategory = async (req: Request, res: Response) => {
  try {
    const id = +req.params.id;

    const category = await getCategoryById(id);
    if (!category)
      return res.status(404).send({ isError: true, message: "Category not found!" });

    await removeCategory(id);

    return res.status(200).send({ msg: "Category deleted successfully" });
  } catch (error) {
    return res.status(400).send({ isError: true, message: (error as any).message || "Something went wrong" });
  }
};