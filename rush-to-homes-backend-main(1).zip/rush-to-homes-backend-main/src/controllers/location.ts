import { Request, Response } from "express";
import { addCity, getCities, getDistrictByName } from "../repositories/location";

export const getAllcities = async (req: Request, res: Response) => {
    const cities = await getCities();
    return res.status(200).send(cities);
};

export const addNewCity = async (req: Request, res: Response) => {
    const data = req.body;
    const dist = await getDistrictByName(data.district);
    data.districtId = dist?.id;
    const city = await addCity(data);
    if(city) return res.status(200).send(data);
    return res.status(400);
};
