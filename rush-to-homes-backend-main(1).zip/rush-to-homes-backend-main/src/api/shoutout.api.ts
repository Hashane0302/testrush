import axios, { AxiosRequestConfig, AxiosInstance, AxiosResponse } from "axios";

const shoutoutApi = (): AxiosInstance => {
  const config: AxiosRequestConfig = {
    baseURL: process.env.SHOUTOUT_OTP_API_BASE_URL,
    headers: {
      "Authorization": `Apikey ${process.env.SHOUTOUT_OTP_API_KEY}`,
      "Content-Type": "application/json"
    }
  };
  return axios.create(config);
};

export const sendOTP = (phoneNumber:string): Promise<AxiosResponse> => {
  return shoutoutApi().post("send", {
    source: process.env.SHOUTOUT_OTP_API_SOURCE,
    transport: "sms",
    content: {
      sms: "Your otp code is {{code}}"
    },
    destination: phoneNumber
  });
};

export const verifyOTP = (code:string, referenceId:string): Promise<AxiosResponse> => {
  return shoutoutApi().post("verify", {
    code,
    referenceId,
  });
};