import "reflect-metadata";
import express, { Express } from "express";
// import http from "http";
import cors from "cors";
import router from "./routes/index";
import dotenv from "dotenv";
import passport from "./middlewares/passport-config";
import { AppDataSource } from "./config/db-config";
import version from "./version";
// import { Server } from "socket.io";
// import { processCommand } from "../socket";
dotenv.config();

const app: Express = express();
app.use(
  cors({
    origin: "*",
    credentials: true,
  })
);

// Bodyparser
//parse url-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: true, limit: "3mb" }));
//parse JSON bodies (as sent by API clients)
app.use(express.json({ limit: "3mb" }));
// Public folder setup
app.use("/public", express.static("./public"));

const host = process.env.HOST || "localhost";
const port = process.env.PORT || 4000;

app.use(passport.initialize());

app.use(`/v${version.split(".")[0]}/api`, router);
app.use("/api", (req, res) =>
  res.send({ status: "Welcome to R2Homes", version: `v${version}` })
);

AppDataSource.initialize().then(() => {
  console.log("Database Connected");
  app.listen({ host, port }, async () => {
    console.log(`⚡️[server]: Server is running at ${host}:${port}`);
  });  
})
.catch((err) => console.log(err));