import { DataSource } from "typeorm";
import {
  UserEntity,
  AdminEntity,
  AdvertisementEntity,
  ImageEntity,
  BannerEntity,
  ReportAdEntity,
  MessageEntity,
  CityEntity,
  DistrictEntity,
  ProvinceEntity,
  PropertyFeatureEntity,
  AdditionalPhoneNumberEntity,
  CategoryEntity,
  AdRemarksEntity,
  ConversationEntity
} from "../entities";
import dotenv from "dotenv";
dotenv.config();

export const AppDataSource = new DataSource({
  type: "mysql",
  host: process.env.DB_HOST || "localhost",
  port: 3306,
  username: process.env.DB_USERNAME || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DATABASE || "rush_to_home",
  synchronize: true,
  logging: false,
  entities: [
    UserEntity,
    AdminEntity,
    AdvertisementEntity,
    ImageEntity,
    BannerEntity,
    ReportAdEntity,
    MessageEntity,
    CityEntity,
    DistrictEntity,
    ProvinceEntity,
    PropertyFeatureEntity,
    AdditionalPhoneNumberEntity,
    CategoryEntity,
    AdRemarksEntity,
    ConversationEntity
  ],
  subscribers: [],
  migrations: [],
});
