import express from "express";
import { getUser, getAllAdmins, getAllUsers, deleteAUser, deleteAnAdmin, updateProfile, uploadProfileImage } from "../controllers/user";
import { ensureAuthenticated } from "../middlewares/authenticate";
import { profileImgUpload } from "../middlewares/multer";
const router = express.Router();

router.get("/", ensureAuthenticated, getUser);
router.get("/get-admins", getAllAdmins);
router.get("/get-users", getAllUsers);
router.post("/delete-user", deleteAUser);
router.post("/delete-admin", deleteAnAdmin);
router.put("/update-profile", ensureAuthenticated, updateProfile);
router.post("/upload-profile-image", profileImgUpload.single("image"), uploadProfileImage);

export default router;
