import express from "express";
import {
  signUp,
  addAdmin,
  signIn,
  test,
  googleAuthCallback,
  facebookAuthCallback,
  authTokenConfirmCallback,
  verifyToken,
  sendOTPCode,
  verifyPhoneNumber,
  renewAccessToken,
  updatePhoneNumber,
  verifyAdmin,
  signInAdmin,
  changePassword,
  forgotPassword,
  validateResetPassword,
  resetPassword
} from "../controllers/auth";
import { ensureAuthenticated } from "../middlewares/authenticate";
import passport from "passport";
const router = express.Router();

router.post("/test", test);
router.post("/sign-up", signUp);
router.post("/add-admin", addAdmin);
router.get("/confirmation/:token", verifyToken);
router.post(
  "/sign-in",
  passport.authenticate("local", { session: false }),
  signIn
);
router.post("/sign-in-admin", signInAdmin);
router.get(
  "/google",
  passport.authenticate("google", { scope: ["profile", "email"] })
);
router.get("/google/callback", googleAuthCallback);
router.get(
  "/facebook",
  passport.authenticate("facebook", { scope: ["email"] })
);
router.get("/facebook/callback", facebookAuthCallback);
router.post("/auth-token-confirm-callback", authTokenConfirmCallback, signIn);
router.post("/validate-admin/", verifyAdmin);
router.post("/renew-access-token", renewAccessToken);
router.post("/send-otp", sendOTPCode);
router.post("/phone-number-verify", verifyPhoneNumber);
router.post("/update-phone-number", updatePhoneNumber);
router.post("/change-password", ensureAuthenticated, changePassword);

router.post("/forgot-password", forgotPassword);
router.post("/validate-password-reset", validateResetPassword);
router.post("/password-reset", resetPassword);

export default router;
