import express from "express";
import { getAdditionalPhones, removeAdditionalPhone, resendOTPToAdditionalPhone, sendOTPToAdditionalPhone, verifyAdditionalPhone } from "../controllers/additional-phone";
import { ensureAuthenticated } from "../middlewares/authenticate";

const router = express.Router();

router.post("/send-otp", ensureAuthenticated, sendOTPToAdditionalPhone);
router.post("/resend-otp/:phoneId", ensureAuthenticated, resendOTPToAdditionalPhone);

router.post("/verify", ensureAuthenticated, verifyAdditionalPhone);
router.get("/all", ensureAuthenticated, getAdditionalPhones);

router.delete("/remove/:phoneId", ensureAuthenticated, removeAdditionalPhone);

export default router;