import express from "express";
import { addCategory, deleteCategory, getAllCategories, getCategory, updateCategory } from "../controllers/category";

const router = express.Router();

router.post("/", addCategory);
router.get("/", getAllCategories);
router.get("/:id", getCategory);
router.put("/:id", updateCategory);
router.delete("/:id", deleteCategory);

export default router;
