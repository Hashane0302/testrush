import express from "express";
import userRouter from "./user";
import advertisementRouter from "./advertisement";
import bannerRouter from "./banner";
import messagesRouter from "./messages";
import emailRouter from "./email";
import authRouter from "./auth";
import locationRouter from "./location";
import categoryRouter from "./category";
import additionalPhoneRouter from "./additional-phone";
const router = express.Router();

router.use("/users", userRouter);
router.use("/advertisements", advertisementRouter);
router.use("/banners", bannerRouter);
router.use("/messages", messagesRouter);
router.use("/email", emailRouter);
router.use("/auth", authRouter);
router.use("/location", locationRouter);
router.use("/category", categoryRouter);
router.use("/additional-phone", additionalPhoneRouter);

export default router;
