import express from "express";
import { sendEmailToAdvertiser } from "../controllers/email";
const router = express.Router();

router.post("/sendEmailToAdvertiser", sendEmailToAdvertiser);

export default router;
