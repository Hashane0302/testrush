import express from "express";
import { addBanner, getBannerList, removeBanner } from "../controllers/banner";
import { ensureAdmin } from "../middlewares/authenticate";
import { bannerUpload } from "../middlewares/multer";

const router = express.Router();

router.get("/", getBannerList);
router.post("/", ensureAdmin, bannerUpload.single("image"), addBanner);
router.delete("/:id", ensureAdmin, removeBanner);

export default router;
