import express from "express";
import {
  getAdvertisementCount,
  getAdvertisementList,
  getAdvertisementDetails,
  reportAdvertisement,
  getAllAdvertisementCities,
  getSimilarAd,
  saveAdvertisement,
  uploadImage,
  postAdvertisement,
  getAdListByAdmin,
  getAdvertisementDetailsByAdmin,
  changeStatusAd,
  getSavedAds,
  removeSavedAds,
  getManageAds,
  editAdvertisement,
  deleteAdvertisement,
} from "../controllers/advertisement";
import { ensureAuthenticated, authenticate } from "../middlewares/authenticate";
import { upload } from "../middlewares/multer";
const router = express.Router();

// Admin routes
router.get("/ad-details/all", getAdListByAdmin);
router.get("/ad-details/:id", getAdvertisementDetailsByAdmin);
router.patch("/ad-details/:id/status-change", changeStatusAd);

// Public/User routes
router.get("/", authenticate, getAdvertisementList);
router.get("/count", getAdvertisementCount);
router.get("/city", getAllAdvertisementCities);

router.get("/similarAd", authenticate, getSimilarAd);

router.post("/report/:id", reportAdvertisement);
router.post("/save/:id", ensureAuthenticated, saveAdvertisement);
router.get("/saved-ads", ensureAuthenticated, getSavedAds);
router.delete("/remove-saved/:id", ensureAuthenticated, removeSavedAds);
router.post("/upload-image", upload.single("image"), uploadImage);

router.post("/post-ad", ensureAuthenticated, postAdvertisement);
router.put("/edit-ad/:id", ensureAuthenticated, editAdvertisement);
router.delete("/delete-ad/:id", ensureAuthenticated, deleteAdvertisement);
router.get("/manage-ads", ensureAuthenticated, getManageAds);

router.get("/:id", authenticate, getAdvertisementDetails);


export default router;
