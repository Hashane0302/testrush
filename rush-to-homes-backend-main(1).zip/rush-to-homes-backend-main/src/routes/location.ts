import express from "express";
import { getAllcities } from "../controllers/location";
import { addNewCity } from "../controllers/location";
const router = express.Router();

router.get("/get-cities", getAllcities);
router.post("/add-city", addNewCity);

export default router;
