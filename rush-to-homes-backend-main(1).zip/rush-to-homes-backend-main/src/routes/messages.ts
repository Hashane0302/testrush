import express from "express";
import { addMessages, getMessageList, getBetweenConversation, updateMsg, getAdConversation } from "../controllers/messages";
import { ensureAuthenticated } from "../middlewares/authenticate";

const router = express.Router();

router.post("/", ensureAuthenticated, addMessages);
router.get("/ad-messages/:adId", ensureAuthenticated, getAdConversation);
router.get("/", ensureAuthenticated, getMessageList);
router.put("/updateMsg", ensureAuthenticated, updateMsg);

router.get("/:conversationId", ensureAuthenticated, getBetweenConversation);

export default router;
