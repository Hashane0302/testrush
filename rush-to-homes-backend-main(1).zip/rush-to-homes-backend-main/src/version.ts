const version = "1.0.5-20230324";

export default version;