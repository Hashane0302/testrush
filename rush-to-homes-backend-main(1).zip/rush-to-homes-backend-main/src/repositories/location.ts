import { AppDataSource } from "../config/db-config";
import { CityEntity, DistrictEntity } from "../entities";

export const getCities = async (): Promise<CityEntity[] | null> => {
  return AppDataSource.getRepository(CityEntity)
    .createQueryBuilder("city")
    .leftJoinAndSelect("city.district", "district")
    .orderBy("district.nameEn", "ASC")
    .addOrderBy("city.nameEn", "ASC")
    .getMany();
};

export const getDistrictAndCitiesList = async (): Promise<DistrictEntity[]> => {
  return AppDataSource.getRepository(DistrictEntity)
    .createQueryBuilder("districts")
    .leftJoinAndSelect("districts.cities", "cities")
    .select(["districts.nameEn", "districts.nameSi", "districts.nameTa", "cities.nameEn", "cities.nameSi", "cities.nameTa"])
    .orderBy("districts.nameEn", "ASC")
    .getMany();
};

export const getDistrictByName = async (district: string): Promise<DistrictEntity | null> => {
  return AppDataSource.getRepository(DistrictEntity)
    .createQueryBuilder("districts")
    .where("districts.nameEn = :district", { district })
    .getOne();
};

export const addCity = async (data: any): Promise<CityEntity> => {
  return AppDataSource.getRepository(CityEntity).save(data);
};