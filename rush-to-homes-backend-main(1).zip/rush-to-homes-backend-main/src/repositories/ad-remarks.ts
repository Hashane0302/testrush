import { AdRemarkData } from "../../types";
import { AppDataSource } from "../config/db-config";
import { AdRemarksEntity } from "../entities";

export const saveRemark = async (data: AdRemarkData): Promise<AdRemarksEntity> => {
  const adRemark = new AdRemarksEntity();
  adRemark.remark = data.remark;
  adRemark.status = data.status;
  adRemark.advertisement = data.advertisement;

  return AppDataSource.getRepository(AdRemarksEntity).save(adRemark);
};