import { AppDataSource } from "../config/db-config";
import { AdditionalPhoneNumberEntity } from "../entities";

export const saveAdditionalPhone = async (data: AdditionalPhoneNumberEntity) => {
  return AppDataSource.getRepository(AdditionalPhoneNumberEntity).save(data);
};

export const getAdditionalPhoneById = async (id: number) => {
  return AppDataSource.getRepository(AdditionalPhoneNumberEntity).findOne({ 
    where: { id },
    relations: { user: true }
  });
};

export const getAdditionalPhoneByNumber = async (countryCode: string, phoneNumber: string) => {
  return AppDataSource.getRepository(AdditionalPhoneNumberEntity).findOne({ 
    where: { countryCode, phoneNumber }
  });
};

export const getAdditionalPhoneByUser = async (userId: number) => {
  return AppDataSource.getRepository(AdditionalPhoneNumberEntity).find({ 
    where: {
      user: { id: userId }
    },
  });
};

export const deleteAdditionalPhone = async (data: AdditionalPhoneNumberEntity) => {
  return AppDataSource.getRepository(AdditionalPhoneNumberEntity).remove(data);
};