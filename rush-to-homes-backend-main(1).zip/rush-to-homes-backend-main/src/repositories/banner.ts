import { AppDataSource } from "../config/db-config";
import { BannerEntity } from "../entities";
import { queryRunner } from "../utils/database";

export const bannerList = async (
  keyWords: string[],
  limit: number | undefined,
  offset: number | undefined
) => {
  let query = `
 SELECT * FROM banner
    `;

  if (keyWords.length > 0) {
    query += " WHERE";
    keyWords.forEach((str: string, index: number) => {
      query += ` title LIKE '%${str}%'`;

      if (keyWords.length !== index + 1) query += " OR";
    });
  }

  if (limit && offset) {
    query += "ORDER BY views ASC LIMIT ? OFFSET ?";
  }

  const { results } = await queryRunner(query, [limit, offset]);
  return results;
};

export const saveBanner = (data: BannerEntity) => {
  return AppDataSource.getRepository(BannerEntity).save(data);
};

export const getBanner = (id: number) => {
  return AppDataSource.getRepository(BannerEntity).findOne({ where: { id } });
};

export const deleteBanner = (banner: BannerEntity) => {
  return AppDataSource.getRepository(BannerEntity).remove(banner);
};

export const updateBannerViews = (bannerIds: any[]) => {
  return AppDataSource.createQueryBuilder()
    .update(BannerEntity)
    .set({ views: () => "views + 1" })
    .whereInIds(bannerIds)
    .execute();
};