import { Brackets, In } from "typeorm";
import { AppDataSource } from "../config/db-config";
import { MessageEntity } from "../entities";
import { ConversationEntity } from "../entities/conversation.entity";

export const saveMessage = async (message: Partial<MessageEntity>) => {
  return AppDataSource.getRepository(MessageEntity).save(message);
};

export const saveConversation = async (conv: ConversationEntity) => {
  return AppDataSource.getRepository(ConversationEntity).save(conv);
};

export const getConversationById = async (id: number) => {
  return AppDataSource.getRepository(ConversationEntity).findOne({ where: { id } });
};

export const getConversationByAdId = async (adId: number, userId: number) => {
  return AppDataSource.getRepository(ConversationEntity).findOne({
    where: {
      ad: { id: adId },
      users: { id: userId }
    }
  });
};

export const fetchMessages = async (
  advertisementId: number,
  userId: number
): Promise<MessageEntity[]> => {
  return AppDataSource.getRepository(MessageEntity)
    .createQueryBuilder("message")
    .where("message.advertisementId = :advertisementId", { advertisementId })
    .andWhere(
      new Brackets((qb) => {
        qb.orWhere("message.senderId = :senderId", { senderId: userId })
        .orWhere("message.receiverId = :receiverId", { receiverId: userId });
      })
    )
    .getMany();
};

export const fetchBetweenConversation = async (conversationId: number, userId: number) => {
  return AppDataSource.getRepository(ConversationEntity).findOne({
    relations: {
      messages: { user: true },
    },
    where: {
      id: conversationId,
      users: { id: userId } 
    }
  });
};

export const fetchConversationId = async (userId: number): Promise<ConversationEntity[]> => {
  return AppDataSource.getRepository(ConversationEntity).find({
    select: {
      id: true
    },
    where: {
      users: { id: userId } 
    }
  });
};

export const fetchConversations = async (ids: number[]): Promise<ConversationEntity[]> => {
  return AppDataSource.getRepository(ConversationEntity).find({
    relations: {
      users: true,
      ad: { images: true },
      messages: { user: true },
    },
    select: {
      id: true,
      users: { id: true, firstName: true, lastName: true },
      ad: { id: true, title: true, images: { locationUrl: true } },
      messages: true
    },
    where: {
      id: In(ids)
    }
  });
};

export const getUnreadMsgCount = async (userId: number): Promise<[]> => {
  return AppDataSource.createQueryRunner().manager.query(
    `SELECT COUNT(message.id) as count FROM message
      LEFT JOIN image ON image.id = (SELECT MIN(id) FROM image WHERE advertisement_id = message.advertisement_id)
      INNER JOIN advertisement ON message.advertisement_id = advertisement.id
      INNER JOIN user ON (CASE
      WHEN message.sender_id != ${userId} THEN sender_id
      WHEN message.receiver_id != ${userId} THEN receiver_id
      END) = user.id WHERE message.id in 
      (SELECT MAX(message.id) FROM message 
      where message.sender_id = ${userId} OR message.receiver_id = ${userId}
      GROUP BY message.advertisement_id, 
      CONCAT(LEAST(message.sender_id, message.receiver_id),'.',
      GREATEST(message.sender_id, message.receiver_id))) AND \`read\` = 0 AND message.sender_id != ${userId}
      ORDER BY message.id DESC;`
  );
};

export const updateMessageReadStatus = async (msgId: number, convId: number, otherUserId: number) => {
  return AppDataSource.getRepository(MessageEntity).update({
    id: msgId,
    user: {
      id: otherUserId
    },
    conversation: {
      id: convId
    }
  }, { read: true });
};
