import { queryRunner } from "../utils/database";
import { AppDataSource } from "../config/db-config";
import { UserEntity, AdminEntity } from "../entities";

export const getUser = async (CountryCode: string) => {
  const query = "SELECT * FROM city WHERE CountryCode = ?";
  const { results } = await queryRunner(query, [CountryCode]);

  return results;
};

export const getAdmins = async (): Promise<AdminEntity[] | null> => {
  return AppDataSource.getRepository(AdminEntity)
    .createQueryBuilder("admin")
    .where("admin.isAdmin = 1")
    .getMany();
};

export const getAdminByEmail = async (
  email: string
): Promise<AdminEntity | null> => {
  return AppDataSource.getRepository(AdminEntity)
    .createQueryBuilder("admin")
    .where("admin.email = :email", { email })
    .getOne();
};

export const getAdminByUserId = async (
  userId: number
): Promise<AdminEntity | null> => {
  return AppDataSource.getRepository(AdminEntity)
    .createQueryBuilder("user")
    .where("user.id = :userId", { userId })
    .getOne();
};

export const deleteAdmin = async (id: number): Promise<void> => {
  await AppDataSource.getRepository(AdminEntity).delete(id);
};

export const insertNewAdmin = async (userData: any): Promise<void> => {
  console.log(userData);
  
  await AppDataSource.getRepository(AdminEntity).save(userData);
};

export const getUsers = async (): Promise<UserEntity[] | null> => {
  return AppDataSource.getRepository(UserEntity)
    .createQueryBuilder("user")
    .where("user.isAdmin = 0")
    .getMany();
};

export const getUserByUserId = async (
  userId: number
): Promise<UserEntity | null> => {
  return AppDataSource.getRepository(UserEntity)
    .createQueryBuilder("user")
    .leftJoinAndSelect("user.advertisements", "advertisements")
    .leftJoinAndSelect("user.favoriteAds", "favoriteAds")
    .where("user.id = :userId", { userId })
    .getOne();
};

export const saveUserDetails = async (data: any): Promise<void> => {
  await AppDataSource.getRepository(UserEntity).save(data);
};

export const getUserByEmail = async (
  email: string
): Promise<UserEntity | null> => {
  return AppDataSource.getRepository(UserEntity)
    .createQueryBuilder("user")
    .addSelect("user.password")
    .leftJoinAndSelect("user.advertisements", "advertisements")
    .leftJoinAndSelect("user.favoriteAds", "favoriteAds")
    .where("user.email = :email", { email })
    .getOne();
};

export const getUserByPassword = async (
  password: string
): Promise<UserEntity | null> => {
  return AppDataSource.getRepository(UserEntity)
    .createQueryBuilder("user")
    .addSelect("user.password")
    .where("user.password = :password", { password })
    .getOne();
};

export const getUserWithPassword = async (userId: number) => {
  return AppDataSource.getRepository(UserEntity)
    .createQueryBuilder("user")
    .addSelect("user.password")
    .where("user.id = :userId", { userId })
    .getOne();
};

export const getUserByPhoneNumber = async (
  phoneNumber: string
): Promise<UserEntity | null> => {
  return AppDataSource.getRepository(UserEntity)
    .createQueryBuilder("user")
    .leftJoinAndSelect("user.advertisements", "advertisements")
    .leftJoinAndSelect("user.favoriteAds", "favoriteAds")
    .where("user.phoneNumber = :phoneNumber", { phoneNumber })
    .getOne();
};

export const getUserIdByEmail = async (
  email: string
): Promise<UserEntity | null> => {
  return AppDataSource.getRepository(UserEntity)
    .createQueryBuilder("user")
    .where("user.email = :email", { email })
    .getOne();
};

export const getUserIdByPhoneNumber = async (
  phoneNumber: string
): Promise<UserEntity | null> => {
  return AppDataSource.getRepository(UserEntity)
    .createQueryBuilder("user")
    .where("user.phoneNumber = :phoneNumber", { phoneNumber })
    .getOne();
};

export const insertNewUser = async (userData: any): Promise<void> => {
  await AppDataSource.getRepository(UserEntity).save(userData);
};

export const updateUserStatus = async (email: string): Promise<void> => {
  await AppDataSource.getRepository(UserEntity).update(
    { email },
    { isVerified: true }
  );
};

export const deleteUser = async (id: number): Promise<void> => {
  await AppDataSource.getRepository(UserEntity).delete(id);
};