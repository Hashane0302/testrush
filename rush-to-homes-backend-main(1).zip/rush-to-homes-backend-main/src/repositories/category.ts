/* eslint-disable @typescript-eslint/no-explicit-any */
import { DeleteResult, UpdateResult } from "typeorm";
import { CategoryData } from "../../types";
import { AppDataSource } from "../config/db-config";
import { CategoryEntity } from "../entities/category.entity";

export const saveCategory = async (category: CategoryData): Promise<CategoryEntity | undefined> => {
  return AppDataSource.getRepository(CategoryEntity).save(category);
};

export const updateCategoryData = async (id: number, category: any): Promise<UpdateResult> => {
  return AppDataSource.getRepository(CategoryEntity).update(id, category);
};

export const getCategoryByName = async (category: any): Promise<CategoryEntity | null> => {
  const { nameEn, nameSi, nameTa } = category;

  return AppDataSource.getRepository(CategoryEntity)
    .createQueryBuilder("category")
    .where("category.nameEn = :nameEn", { nameEn })
    .orWhere("category.nameSi = :nameSi", { nameSi })
    .orWhere("category.nameTa = :nameTa", { nameTa })
    .getOne();
};

export const getCategoryById = async (id: number): Promise<CategoryEntity | null> => {
  return AppDataSource.getRepository(CategoryEntity)
    .createQueryBuilder("category")
    .where("category.id = :id", { id })
    .getOne();
};

export const getAllCategoryList = async (offset: number, limit: number): Promise<CategoryEntity[]> => {
  return AppDataSource.getRepository(CategoryEntity)
    .createQueryBuilder("category")
    .skip(offset)
    .take(limit)
    .getMany();
};

export const removeCategory = async (id: number): Promise<DeleteResult> => {
  return AppDataSource.getRepository(CategoryEntity).delete(id);
};