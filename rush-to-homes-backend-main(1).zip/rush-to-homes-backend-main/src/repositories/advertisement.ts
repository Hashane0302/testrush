import { ReportedAddDataType } from "../../types";
import { FilterParams } from "../../types";
import { AppDataSource } from "../config/db-config";
import { AdvertisementEntity, ReportAdEntity, PropertyFeatureEntity, ImageEntity } from "../entities";
import { Brackets, SelectQueryBuilder, UpdateResult } from "typeorm";

const advertisementFilterQueryBuilder = (
  params: FilterParams
): SelectQueryBuilder<AdvertisementEntity> => {
  const {
    searchStr,
    propertyTypes,
    // priceRangeType,
    priceRangeMin,
    priceRangeMax,
    district,
    city,
    landRangeType,
    landRangeMin,
    landRangeMax,
    searchType
  } = params;

  return AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .where(
      new Brackets((qb) => {
        searchStr.reduce((ac, c, i) => {
          if (i === 0)
            return qb.where("advertisement.title LIKE :str", { str: `%${c}%` });
          else
            return ac.orWhere("advertisement.title LIKE :str", {
              str: `%${c}%`,
            });
        }, qb);
      })
    )
    .andWhere(
      new Brackets((qb) => {
        propertyTypes.reduce((ac, c, i) => {
          if (i === 0)
            return qb.where("advertisement.propertyType = :propertyType", {
              propertyType: c,
            });
          else
            return ac.orWhere("advertisement.propertyType = :propertyType", {
              propertyType: c,
            });
        }, qb);
      })
    )
    .andWhere(
      new Brackets((qb) => {
        if (
          // priceRangeType !== undefined &&
          priceRangeMin !== undefined &&
          priceRangeMax !== undefined
        ) {
          // if (priceRangeType === "perPerch") {
          //   qb.where(
          //     "(advertisement.price/(advertisement.landArea)) >= :min",
          //     { min: priceRangeMin }
          //   ).andWhere(
          //     "(advertisement.price/(advertisement.landArea)) <= :max",
          //     { max: priceRangeMax }
          //   );
          // } else if (priceRangeType === "perAcre") {
          //   qb.where(
          //     "(advertisement.price/(advertisement.landArea * (1/160))) >= :min",
          //     { min: priceRangeMin }
          //   ).andWhere(
          //     "(advertisement.price/(advertisement.landArea * (1/160))) <= :max",
          //     { max: priceRangeMax }
          //   );
          // } else {
            qb.where("advertisement.price >= :min", { min: priceRangeMin })
              .andWhere("advertisement.price <= :max", { max: priceRangeMax });
          // }
        }
      })
    )
    .andWhere(
      new Brackets((qb) => {
        if (district) {
          qb.where("advertisement.district = :district", {
            district: district,
          });
        }
      })
    )
    .andWhere(
      new Brackets((qb) => {
        if (city) {
          qb.where("advertisement.city = :city", { city: city });
        }
      })
    )
    .andWhere(
      new Brackets((qb) => {
        if (
          landRangeType !== undefined &&
          landRangeMin !== undefined &&
          landRangeMax !== undefined
        ) {
          if (landRangeType === "byPerch") {
            qb.where("advertisement.landArea >= :min", {
              min: landRangeMin,
            }).andWhere("advertisement.landArea <= :max", {
              max: landRangeMax,
            });
          } else {
            qb.where(
              "(advertisement.landArea * 160) >= :min",
              { min: landRangeMin }
            ).andWhere(
              "(advertisement.landArea * 160) <= :max",
              { max: landRangeMax }
            );
          }
        }
      })
    )
    .andWhere(new Brackets((qb) => {
      if(searchType === "Sale") {
        qb.where("advertisement.offerType = :searchType", { searchType });
      }
      else if(searchType === "Rent") {
        qb.where("advertisement.offerType = :searchType", { searchType });
      }
      else if(searchType === "Land") {
        qb.where("advertisement.propertyType = :searchType", { searchType });
      }
    }))
    .andWhere("advertisement.status = :status", { status: 3 });
};

const constructSearchQuery = (qb: SelectQueryBuilder<AdvertisementEntity>, searchTerm: [string, string][]): SelectQueryBuilder<AdvertisementEntity> => {

  searchTerm.forEach((e, idx) => {
    let where = "";
    let param: { [key: string]: string; } = {};

    switch (e[0]) {
      case "code":
        where = "advertisement.id like :code";
        param = { code: `%${e[1]}%` };
        break;
      case "title":
        where = "LOWER(advertisement.title) like :title";
        param = { title: `%${e[1].toLowerCase()}%` };
        break;
      case "uname":
        where = "(LOWER(user.firstName) like :firstName OR LOWER(user.lastName) like :lastName)";
        param = { firstName: `%${e[1].toLowerCase()}%`, lastName: `%${e[1].toLowerCase()}%` };
        break;
    }

    if (idx === 0)
      qb = qb.where(where, param);
    else
      qb = qb.andWhere(where, param);
  });

  return qb;
};

export const advertisementCount = async (
  params: FilterParams
): Promise<number> => {
  return advertisementFilterQueryBuilder(params).getCount();
};

export const advertisementList = async (
  params: FilterParams,
  limit: number | undefined,
  offset: number | undefined
): Promise<AdvertisementEntity[]> => {
  const { sortBy, sortOrder } = params;

  return advertisementFilterQueryBuilder(params)
    .leftJoinAndSelect("advertisement.images", "images")
    .leftJoinAndSelect("advertisement.favoriteUsers", "favoriteUsers")
    .orderBy(`advertisement.${sortBy}`, sortOrder)
    .skip(offset)
    .take(limit)
    .getMany();
};

export const advertisementCitiesList = async (): Promise<
  { district: string; city: string }[]
> => {
  return AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .select(["advertisement.district", "advertisement.city"])
    .getMany();
};

export const getAdvertisement = async (
  advertisementId: number
): Promise<AdvertisementEntity | null> => {
  return AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .leftJoinAndSelect("advertisement.images", "images")
    .leftJoinAndSelect("advertisement.propertyFeatures", "propertyFeatures")
    .leftJoinAndSelect("advertisement.favoriteUsers", "favoriteUsers")
    .leftJoinAndSelect("advertisement.user", "user")
    .where("advertisement.id = :advertisementId", { advertisementId })
    .getOne();
};

export const removeAdvertisement = async (advertisementId: number) => {
  try {
    await AppDataSource.getRepository(PropertyFeatureEntity).delete({ advertisementId });
    await AppDataSource.getRepository(ImageEntity).delete({ advertisementId });
    await AppDataSource.getRepository(AdvertisementEntity).delete({ id: advertisementId });
  } catch (err) {
    console.log(err);
  }
};

export const reportAdd = async (
  reportedAdd: ReportedAddDataType
): Promise<void> => {
  await AppDataSource.getRepository(ReportAdEntity).save(reportedAdd);
};

export const getAllAdvertisementListByPropertyType = async (
  propertyType: string,
  offerType: string
): Promise<AdvertisementEntity[]> => {
  return AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .where("advertisement.propertyType = :propertyType", { propertyType })
    .andWhere("advertisement.offerType = :offerType", { offerType })
    .andWhere("advertisement.status = :status", { status: 3 })
    .getMany();
};

export const getAdvertisementListByIds = async (
  ids: number[]
): Promise<AdvertisementEntity[]> => {
  return AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .leftJoinAndSelect("advertisement.images", "images")
    .leftJoinAndSelect("advertisement.favoriteUsers", "favoriteUsers")
    .whereInIds(ids)
    .andWhere("advertisement.status = :status", { status: 3 })
    .getMany();
};

export const getAdvertisementListByUser = async (userId: number, status = 3): Promise<AdvertisementEntity[]> => {
  return AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .leftJoinAndSelect("advertisement.images", "images")
    .leftJoinAndSelect("advertisement.user", "user")
    .where("user.id = :userId", { userId })
    .andWhere("advertisement.status = :status", { status })
    .getMany();
};

export const createAdvertisement = async (data: any): Promise<void> => {
  const response = await AppDataSource.getRepository(AdvertisementEntity).save({ ...data, status: 1 });

  const advertisementId = response.id;
  if (data.propertyFeatures && data.propertyFeatures.length) {
    const propertyFeatures = data.propertyFeatures.map((feature:string) => ({ advertisementId, feature }));
    await AppDataSource.getRepository(PropertyFeatureEntity).save(propertyFeatures);
  }

  if (data.images && data.images.length) {
    const images = data.images.map((image: any) => ({ advertisementId, fileName: image.fileName, locationUrl: image.locationUrl }));
    await AppDataSource.getRepository(ImageEntity).save(images);
  }
};

export const updateAdvertisement = async (advertisementId: number, data: any): Promise<void> => {
  try {
    if (data.propertyFeatures && data.propertyFeatures.length) {
      const propertyFeatures = data.propertyFeatures.map((feature: string) => ({
        advertisementId,
        feature: feature
      } as PropertyFeatureEntity));
      await AppDataSource.getRepository(PropertyFeatureEntity).delete({ advertisementId });
      await AppDataSource.getRepository(PropertyFeatureEntity).save(propertyFeatures);
    }

    if (data.images && data.images.length) {
      const images = data.images.map((image: any) => ({
        advertisementId,
        fileName: image.fileName,
        locationUrl: image.locationUrl
      } as ImageEntity));
      await AppDataSource.getRepository(ImageEntity).delete({ advertisementId });
      await AppDataSource.getRepository(ImageEntity).save(images);
    }

    await AppDataSource.getRepository(AdvertisementEntity).update(advertisementId, {
      offerType: data.offerType,
      propertyType: data.propertyType,
      price: data.price,
      priceUnit: data.priceUnit,
      title: data.title,
      bedroom: data.bedroom,
      bathroom: data.bathroom,
      floorArea: data.floorArea,
      floor: data.floor,
      carParkingSpace: data.carParkingSpace,
      landArea: data.landArea,
      propertyDetails: data.propertyDetails,
      district: data.district,
      city: data.city,
      searchString: data.searchString,
      status: 1,
    });
  } catch (err) {
    console.log(err);
  }
};

export const getAllReportedAds = async (offset: number, limit: number, searchTerm: [string, string][]): Promise<AdvertisementEntity[]> => {
  let qb = AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .innerJoinAndSelect("advertisement.reports", "reports")
    .leftJoinAndSelect("advertisement.user", "user");

  qb = constructSearchQuery(qb, searchTerm);

  return qb.skip(offset)
    .take(limit)
    .getMany();
};

export const getAdByAdmin = async (advertisementId: number): Promise<AdvertisementEntity | null> => {
  return AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .leftJoinAndSelect("advertisement.images", "images")
    .leftJoinAndSelect("advertisement.propertyFeatures", "propertyFeatures")
    .leftJoinAndSelect("advertisement.favoriteUsers", "favoriteUsers")
    .leftJoinAndSelect("advertisement.user", "user")
    .leftJoinAndSelect("advertisement.reports", "reports")
    .where("advertisement.id = :advertisementId", { advertisementId })
    .getOne();
};

export const getAllAdsByAdmin = async (offset: number, limit: number, status: number | "all", searchTerm: [string, string][]): Promise<AdvertisementEntity[]> => {
  let qb = AppDataSource.getRepository(AdvertisementEntity)
    .createQueryBuilder("advertisement")
    .leftJoinAndSelect("advertisement.user", "user");

  qb = constructSearchQuery(qb, searchTerm);

  if (status !== "all") {
    if (searchTerm.length)
      qb = qb.andWhere("advertisement.status = :status", { status });
    else
      qb = qb.where("advertisement.status = :status", { status });
  }
    
  return qb.orderBy("advertisement.updatedDate", "DESC")
    .skip(offset)
    .take(limit)
    .getMany();
};

export const updateAdByAdmin = async (
  advertisementId: number,
  data: Partial<AdvertisementEntity>
): Promise<UpdateResult> => {
  return AppDataSource.getRepository(AdvertisementEntity).update(advertisementId, data);
};
