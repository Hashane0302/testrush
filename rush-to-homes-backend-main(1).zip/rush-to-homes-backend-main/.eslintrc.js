module.exports = {
    "env": {
        "node": true,
        "jest": true,
        "es2021": true
    },
    "extends": [
        "eslint:recommended",
        "plugin:@typescript-eslint/recommended"
    ],
    "parser": "@typescript-eslint/parser",
    "parserOptions": {
        "ecmaVersion": "latest",
        "sourceType": "module"
    },
    "plugins": [
        "@typescript-eslint"
    ],
    "rules": {
        "quotes": ["error", "double"],
        "camelcase": ["error", { properties: "always" }],
        "object-curly-spacing": ["error", "always", { "arraysInObjects": true, "objectsInObjects": true }],
        "comma-spacing": ["error", { "before": false, "after": true }],
        "array-bracket-spacing": ["error", "never"],
        "lines-between-class-members": ["error", "always", { "exceptAfterSingleLine": true }],
        "semi": ["error", "always"],
        "arrow-spacing": "error",
        "no-extra-semi": "error",
        "semi-spacing": "error",
        "space-before-function-paren": ["error", {
            "anonymous": "never",
            "named": "never",
        }],
        "space-before-blocks": ["error", "always"],
        "key-spacing": ["error", { "afterColon": true, "beforeColon": false }],
        "@typescript-eslint/no-explicit-any": "off"
    }
};
