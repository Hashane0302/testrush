# rush-to-homes-backend

.env
HOST=localhost
PORT=4000

DB_HOST= 
DB_USERNAME= 
DB_PASSWORD= 
DATABASE=